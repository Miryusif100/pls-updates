﻿# PLS-i kompüterdən silir (Q-51): tapşırıq, Startup, brauzer körpüsü, Başlanğıc menyusu və YALNIZ PLS-in öz faylları.
# Tərtibatçı kompüterindəki "PLS Sinxron" faylları (sync\, github*.cred, sync.json, sync.log, tags-*.txt, channel.txt) toxunulmaz qalır.
# Naməlum fayllar da silinmir — qovluq yalnız boş qalanda silinir.
#   -Ask       əvvəlcə təsdiq soruşur (PLS-Sil.cmd)
#   -TestMode  yalnız testlər: PLS_ROOT mühit dəyişəni oxunur, Windows qeydiyyatına toxunulmur
param([switch]$Ask, [switch]$TestMode)
$ErrorActionPreference = 'SilentlyContinue'
$HostName = 'az.plsconsulting.updater'
$Root = if ($TestMode -and $env:PLS_ROOT) { $env:PLS_ROOT } else { Join-Path $env:LOCALAPPDATA 'PLS' }

if ($Ask) {
  Write-Host ''
  Write-Host '  PLS bu kompüterdən silinəcək (genişlənmənin faylları, yeniləyici, qısayollar).' -ForegroundColor Yellow
  $a = Read-Host '  Davam edilsin? (B = bəli)'
  if ($a -notmatch '^\s*[BbYy]') { Write-Host '  Silinmədi.'; exit 0 }
}

if (-not $TestMode) {
  if (Get-Command Unregister-ScheduledTask -ErrorAction SilentlyContinue) { Unregister-ScheduledTask -TaskName 'PLS Yenileyici' -Confirm:$false -ErrorAction SilentlyContinue }
  Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath('Startup')) 'PLS Yenileyici.vbs') -Force
  Remove-Item -Path "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$HostName" -Recurse -Force
  Remove-Item -Path "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\$HostName" -Recurse -Force
  Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath('Programs')) 'PLS') -Recurse -Force
}

# C14 (audit, 13.11.2026): genişlənmənin brauzerdəki məlumatı da silinir — storage.local (ASAN siyahısının nüsxəsi, göndərmə növbəsi),
# IndexedDB (sessiya tokeni, giriş jurnalı). Genişlənmənin ID-si sabitdir (wxt.config.ts `key`). Bütün Chrome/Edge profillərində.
# Brauzer açıqdırsa fayllar kilidli olur — əvvəl bağlamaq istənir; bağlanmasa, nə silinmədiyi aydın yazılır.
$ExtId = 'mgfgihjfnhhmbljfcpknoomaljpgfalf'
$browserRoots = if ($TestMode) { @($env:PLS_TEST_BROWSER_DATA | Where-Object { $_ }) } else {
  @((Join-Path $env:LOCALAPPDATA 'Google\Chrome\User Data'), (Join-Path $env:LOCALAPPDATA 'Microsoft\Edge\User Data')) | Where-Object { Test-Path -LiteralPath $_ }
}
if (-not $TestMode -and $browserRoots.Count -and (Get-Process -Name chrome, msedge -ErrorAction SilentlyContinue)) {
  Write-Host ''
  Write-Host '  Chrome / Edge açıqdır — PLS-in brauzerdəki məlumatını silmək üçün onları bağlayın.' -ForegroundColor Yellow
  if ($Ask) { Read-Host '  Bağladıqdan sonra Enter basın' | Out-Null }
}
$wiped = 0; $locked = 0
foreach ($ud in $browserRoots) {
  foreach ($prof in @(Get-ChildItem -LiteralPath $ud -Directory -Force -ErrorAction SilentlyContinue)) {
    $targets = @(
      (Join-Path $prof.FullName "Local Extension Settings/$ExtId"),
      (Join-Path $prof.FullName "Sync Extension Settings/$ExtId"),
      (Join-Path $prof.FullName "Managed Extension Settings/$ExtId"),
      (Join-Path $prof.FullName "Storage/ext/$ExtId"),
      (Join-Path $prof.FullName "IndexedDB/chrome-extension_$($ExtId)_0.indexeddb.leveldb"),
      (Join-Path $prof.FullName "IndexedDB/chrome-extension_$($ExtId)_0.indexeddb.blob")
    )
    foreach ($t in $targets) {
      if (-not (Test-Path -LiteralPath $t)) { continue }
      Remove-Item -LiteralPath $t -Recurse -Force -ErrorAction SilentlyContinue
      if (Test-Path -LiteralPath $t) { $locked++ } else { $wiped++ }
    }
  }
}

$own = @('extension', 'updater', 'package', 'logs', 'staging', 'updater.log',
  'PLS-Qurasdir.cmd', 'PLS-Yenile.cmd', 'PLS-Sil.cmd', 'PLS-Diaqnostika.cmd', 'OXU-MENI.txt')
foreach ($p in $own) { Remove-Item -LiteralPath (Join-Path $Root $p) -Recurse -Force }

$dev = @(Get-ChildItem -LiteralPath $Root -Force | Where-Object { $_.Name -match '^(sync|sync\.json|sync\.log|github.*\.cred|tags-.*\.txt|channel\.txt)$' } | ForEach-Object { $_.Name })
$left = @(Get-ChildItem -LiteralPath $Root -Force)
if (-not $left.Count) { Remove-Item -LiteralPath $Root -Recurse -Force }

Write-Host ''
Write-Host '  PLS silindi. Chrome-da chrome://extensions səhifəsindən PLS kartını da "Remove" edin.' -ForegroundColor Green
if ($wiped) { Write-Host "  Brauzerdəki PLS məlumatı (yaddaş, sessiya, jurnal) silindi: $wiped qovluq." -ForegroundColor Green }
if ($locked) { Write-Host "  Brauzer açıq olduğu üçün $locked qovluq silinmədi — Chrome/Edge-i bağlayıb PLS-Sil.cmd-i yenidən işə salın və ya chrome://extensions-dan PLS-i «Remove» edin." -ForegroundColor Yellow }
if ($dev.Count) {
  Write-Host "  Tərtibatçı faylları saxlanıldı, 'PLS Sinxron' işləməyə davam edir: $($dev -join ', ')" -ForegroundColor Yellow
} elseif ($left.Count) {
  Write-Host "  Qovluqda başqa fayllar qaldı, silinmədi: $Root" -ForegroundColor Yellow
}
