﻿# PLS quraşdırıcısı (Q-45 "tək qovluq"). Administrator icazəsi tələb etmir; hər şey istifadəçinin öz qovluğuna yazılır.
# Paylama dəsti (PLS\ qovluğu: USB, masaüstü, açılmış PLS.zip) haradan işə salınsa da, özünü %LOCALAPPDATA%\PLS-ə köçürür
# və hər şeyi oradan qeydiyyatdan keçirir. Təkrar işə salmaq təhlükəsizdir (təmir).
#   1) dəst → %LOCALAPPDATA%\PLS (PLS-*.cmd, OXU-MENI.txt, updater\, package\, logs\)
#   2) genişlənmə: internet varsa son versiya (commit SHA feed), yoxdursa package\ — hər iki halda sha256 + RSA imzası yoxlanılır
#   3) native host (Chrome + Edge), Startup, "PLS Yenileyici" tapşırığı (15 dəq.), Başlanğıc menyusunda "PLS" qovluğu
#   4) extension yolu buferə, OXU-MENI.txt və chrome://extensions açılır
$ErrorActionPreference = 'Stop'
$ExtensionId = 'mgfgihjfnhhmbljfcpknoomaljpgfalf'
$HostName = 'az.plsconsulting.updater'
$KitFiles = @('PLS-Qurasdir.cmd', 'PLS-Yenile.cmd', 'PLS-Sil.cmd', 'PLS-Diaqnostika.cmd', 'OXU-MENI.txt')

$Root = Join-Path $env:LOCALAPPDATA 'PLS'
$UpdDir = Join-Path $Root 'updater'
$ExtDir = Join-Path $Root 'extension'
$PkgDir = Join-Path $Root 'package'

# Dəstin kökü: yeni quruluşda bu skript updater\ içindədir; köhnə (düz) quruluşda dəstin özündədir.
$KitDir = Split-Path -Parent $PSScriptRoot
if (-not (Test-Path -LiteralPath (Join-Path $KitDir 'PLS-Qurasdir.cmd'))) { $KitDir = $PSScriptRoot }
$KitUpd = if (Test-Path -LiteralPath (Join-Path $KitDir 'updater\pls-updater.ps1')) { Join-Path $KitDir 'updater' } else { $PSScriptRoot }
function Same([string]$a, [string]$b) { return [IO.Path]::GetFullPath($a).TrimEnd('\') -eq [IO.Path]::GetFullPath($b).TrimEnd('\') }

Write-Host ''
Write-Host '  PLS Consulting — PLS genişlənməsinin quraşdırılması' -ForegroundColor Green
Write-Host '  ---------------------------------------------------'
Write-Host ''

# 1) Faylları köçür
foreach ($d in $Root, $UpdDir, $PkgDir, (Join-Path $Root 'logs')) { New-Item -ItemType Directory -Path $d -Force | Out-Null }
if (-not (Same $KitDir $Root)) {
  foreach ($f in $KitFiles) {
    $s = Join-Path $KitDir $f
    if (Test-Path -LiteralPath $s) { Copy-Item -LiteralPath $s -Destination (Join-Path $Root $f) -Force }
  }
  Get-ChildItem -LiteralPath $KitUpd -File | Where-Object { $_.Extension -in '.ps1', '.cmd', '.vbs' } | ForEach-Object {
    Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $UpdDir $_.Name) -Force
  }
  $kitPkg = Join-Path $KitDir 'package'
  if (Test-Path -LiteralPath $kitPkg) {
    Get-ChildItem -LiteralPath $kitPkg -File -Filter 'pls-*' | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $PkgDir $_.Name) -Force }
  }
}
Get-ChildItem -LiteralPath $Root -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue
foreach ($d in $UpdDir, $PkgDir) { Get-ChildItem -LiteralPath $d -File -ErrorAction SilentlyContinue | Unblock-File -ErrorAction SilentlyContinue }
Write-Host "  [1/5] Fayllar köçürüldü: $Root"

# Yeniləyicinin funksiyaları (açarın barmaq izi, tapşırıq)
. (Join-Path $UpdDir 'pls-updater.ps1') -Quiet
Write-Host "        PLS açarının barmaq izi: $(Get-PlsKeyFingerprint)" -ForegroundColor DarkGray

# 2) Genişlənmə: onlayn (SHA feed), alınmasa package\ — imza hər iki halda yoxlanılır
Write-Host '  [2/5] Genişlənmə quraşdırılır (imza yoxlanılır)...'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $UpdDir 'pls-updater.ps1') -Now -Force
if ($LASTEXITCODE -ne 0 -or -not (Test-Path -LiteralPath (Join-Path $ExtDir 'manifest.json'))) {
  throw 'Genişlənməni quraşdırmaq alınmadı. İnternet bağlantısını yoxlayın və yenidən cəhd edin (və ya dəstdə package\ qovluğu olmalıdır).'
}

# 3) Chrome və Edge üçün körpü (native messaging): "İndi yenilə" və kompüter ID-si
$hostManifest = [ordered]@{
  name = $HostName
  description = 'PLS yeniləyici'
  path = (Join-Path $UpdDir 'native-host.cmd')
  type = 'stdio'
  allowed_origins = @("chrome-extension://$ExtensionId/")
}
$hostJson = Join-Path $UpdDir "$HostName.json"
[IO.File]::WriteAllText($hostJson, ($hostManifest | ConvertTo-Json), (New-Object Text.UTF8Encoding $false))
foreach ($browserKey in 'HKCU:\Software\Google\Chrome\NativeMessagingHosts', 'HKCU:\Software\Microsoft\Edge\NativeMessagingHosts') {
  $k = Join-Path $browserKey $HostName
  New-Item -Path $k -Force | Out-Null
  Set-ItemProperty -Path $k -Name '(default)' -Value $hostJson
}
Write-Host '  [3/5] Brauzer körpüsü qeydiyyatdan keçdi (Chrome, Edge)'

# 4) Windows açılanda və hər 15 dəqiqədən bir yoxlama
$startup = [Environment]::GetFolderPath('Startup')
$vbs = Join-Path $startup 'PLS Yenileyici.vbs'
$content = [IO.File]::ReadAllText((Join-Path $UpdDir 'run-updater.vbs')).Replace('dir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)', "dir = `"$UpdDir`"")
[IO.File]::WriteAllText($vbs, $content, [Text.Encoding]::Default)
try { Register-PlsTask; $taskOk = $true } catch {
  $taskOk = $false
  Write-Host "        (Tapşırıq yaradılmadı: $($_.Exception.Message). Windows açılanda yoxlama işləyəcək.)" -ForegroundColor Yellow
}
Write-Host ('  [4/5] Avtomatik yoxlama: Windows açılanda' + $(if ($taskOk) { ' və hər 15 dəqiqə' } else { '' }))

# 5) Başlanğıc menyusu: "PLS" qovluğu
try {
  $menu = Join-Path ([Environment]::GetFolderPath('Programs')) 'PLS'
  New-Item -ItemType Directory -Path $menu -Force | Out-Null
  $ws = New-Object -ComObject WScript.Shell
  foreach ($l in @(
      @{ Name = 'PLS qovluğu'; Target = $Root; Args = '' },
      @{ Name = 'PLS-i yenilə'; Target = (Join-Path $Root 'PLS-Yenile.cmd'); Args = '' },
      @{ Name = 'PLS-i sil'; Target = (Join-Path $Root 'PLS-Sil.cmd'); Args = '' })) {
    $s = $ws.CreateShortcut((Join-Path $menu "$($l.Name).lnk"))
    $s.TargetPath = $l.Target
    $s.WorkingDirectory = $Root
    $s.Save()
  }
  Write-Host '  [5/5] Başlanğıc menyusunda "PLS" qovluğu yaradıldı'
} catch { Write-Host "  [5/5] Qısayollar yaradılmadı: $($_.Exception.Message)" -ForegroundColor Yellow }

Set-Clipboard -Value $ExtDir -ErrorAction SilentlyContinue
Write-Host ''
Write-Host '  Hazırdır! Son addım — Chrome-da bir dəfə (OXU-MENI.txt-də də yazılıb):' -ForegroundColor Green
Write-Host '    1. chrome://extensions səhifəsi açılır (açılmasa, ünvan sətrinə yazın)'
Write-Host '    2. Sağ yuxarıda "Developer mode" açın'
Write-Host '    3. "Load unpacked" basın, ünvan sətrinə Ctrl+V edin və "Select folder" basın:'
Write-Host "       $ExtDir" -ForegroundColor Yellow
Write-Host ''
Write-Host '  Bundan sonra yeniləmələr avtomatikdir. Əl ilə: Başlanğıc menyusu → PLS → "PLS-i yenilə".'
Write-Host ''
try { Start-Process notepad.exe -ArgumentList "`"$(Join-Path $Root 'OXU-MENI.txt')`"" } catch {}
try { Start-Process 'chrome.exe' -ArgumentList 'chrome://extensions' } catch {
  try { Start-Process 'msedge.exe' -ArgumentList 'edge://extensions' } catch {}
}
