@echo off
chcp 65001 >nul
title PLS yenileme
rem PLS-i indi yenileyir: internetden (commit SHA ile). Internet yoxdursa package\ qovlugundaki imzali paketden.
rem Zip faylini (pls-X.Y.Z.zip, yaninda pls-X.Y.Z.json) bu faylin uzerine surukleseniz, hemin paket qurasdirilir.
rem Imza her zaman yoxlanilir; kohne versiya qurasdirilmir.
set "PLSU=%~dp0updater"
if not exist "%PLSU%\pls-updater.ps1" set "PLSU=%~dp0."
set "PLSPKG=%~1"
if defined PLSPKG goto paket
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PLSU%\pls-updater.ps1" -Now & echo. & pause & exit /b
:paket
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PLSU%\pls-updater.ps1" -Now -Package "%PLSPKG%" & echo. & pause & exit /b
