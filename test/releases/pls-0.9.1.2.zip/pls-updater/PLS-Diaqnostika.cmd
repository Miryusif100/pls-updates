@echo off
chcp 65001 >nul
title PLS diaqnostika
rem Masaustunde PLS-diaqnostika-<tarix>.zip yaradir (jurnal + versiyalar; sifre, token, sexsi melumat yoxdur).
set "PLSU=%~dp0updater"
if not exist "%PLSU%\diaqnostika.ps1" set "PLSU=%~dp0."
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PLSU%\diaqnostika.ps1" & echo. & pause & exit /b
