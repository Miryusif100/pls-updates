@echo off
chcp 65001 >nul
title PLS silinmesi
rem PLS-i silir (yalniz oz fayllarini). Skript muveqqeti qovluqdan isleyir, cunki bu fayl da silinir.
set "PLSU=%~dp0updater"
if not exist "%PLSU%\uninstall.ps1" set "PLSU=%~dp0."
copy /y "%PLSU%\uninstall.ps1" "%TEMP%\pls-sil.ps1" >nul
cd /d "%TEMP%"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%TEMP%\pls-sil.ps1" -Ask & echo. & pause & del "%TEMP%\pls-sil.ps1" >nul 2>&1 & exit /b
