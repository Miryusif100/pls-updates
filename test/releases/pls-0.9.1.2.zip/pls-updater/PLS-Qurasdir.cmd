@echo off
chcp 65001 >nul
title PLS qurasdirici
rem Qovlugu harada olmasindan asili olmayaraq PLS-i %LOCALAPPDATA%\PLS-e qurasdirir (tekrar ise salmaq tehlukesizdir).
set "PLSU=%~dp0updater"
if not exist "%PLSU%\install.ps1" set "PLSU=%~dp0."
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%PLSU%\install.ps1" & echo. & pause & exit /b
