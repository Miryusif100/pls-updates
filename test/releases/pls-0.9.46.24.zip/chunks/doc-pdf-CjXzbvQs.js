const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["chunks/jspdf.es.min-BDhsQhkl.js","chunks/rolldown-runtime-C0FnF6B9.js","chunks/preload-helper-B5lxZYkR.js"])))=>i.map(i=>d[i]);
import{r as e}from"./rolldown-runtime-C0FnF6B9.js";import{t}from"./initials-BSjEUpVq.js";import{t as n}from"./preload-helper-B5lxZYkR.js";var r=1123,i=e=>e.replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e]),a=794/545,o=e=>`${Math.round(e*a*100)/100}px`,s=`
.dpg { position: relative; box-sizing: border-box; width: 794px; min-height: ${r}px; padding: 56px 56px 64px; background: #fff; color: #111; font: 400 12.5px/1.45 'IBM Plex Sans', Arial, sans-serif; }
.dpg * { box-sizing: border-box; }
.dpg p { margin: 0 0 6px; }
.dpg h1 { margin: 0 0 3px; font-size: 17px; font-weight: 700; text-align: center; letter-spacing: .01em; }
.dpg .dp-sub { text-align: center; margin: 0 0 16px; }
.dpg .dp-intro { margin: 0 0 12px; text-align: justify; }
.dpg table.dp-items { width: 100%; border-collapse: collapse; margin: 4px 0 8px; }
.dpg table.dp-items th, .dpg table.dp-items td { border: 1px solid #222; padding: 4px 6px; vertical-align: top; }
.dpg table.dp-items th { background: #eef1f5; font-weight: 700; text-align: center; font-size: 11.5px; }
.dpg .al { text-align: left; } .dpg .ar { text-align: right; white-space: nowrap; font-variant-numeric: tabular-nums; } .dpg .ac { text-align: center; }
.dpg .dp-tot { width: 100%; border-collapse: collapse; margin: 2px 0 8px; }
.dpg .dp-tot td { padding: 2px 6px; text-align: right; } .dpg .dp-tot td:first-child { width: 75%; } .dpg .dp-tot tr.b td { font-weight: 700; }
.dpg .dp-sign { width: 100%; border-collapse: collapse; margin-top: 22px; }
.dpg .dp-sign td { width: 50%; vertical-align: top; padding: 0 8px 0 0; }
.dpg .dp-sign .dp-st { font-weight: 700; } .dpg .dp-sign .dp-org { margin-bottom: 8px; } .dpg .dp-sign .dp-pp { margin: 0 0 3px; }
.dpg .dp-sign .dp-line { margin-top: 4px; } .dpg .dp-sign .dp-my { margin-top: 8px; }
.dpg .dp-foot { margin-top: 26px; font-size: 10px; font-style: italic; color: #444; }
`,c=`
.dpg.dcl, .dpg.dmd { padding: 0; display: flex; flex-direction: column; }
.dpg .x-bd { display: flex; flex-direction: column; flex: 1; }
.dpg .dp-en { font-style: italic; color: #4a5568; font-weight: 400; }
.dpg .x-qrw { display: flex; justify-content: flex-end; margin-top: auto; padding-top: ${o(10)}; }
.dpg .x-qrb { display: flex; flex-direction: column; align-items: center; gap: ${o(2)}; flex: none; }
.dpg .x-qrb img { display: block; width: ${o(64)}; height: ${o(64)}; image-rendering: pixelated; }
.dpg .x-qrb small { font-size: ${o(7.8)}; letter-spacing: .02em; white-space: nowrap; }
.dpg .dp-ftr { display: flex; align-items: center; gap: ${o(10)}; font-size: ${o(8.2)}; line-height: 1.35; }
.dpg .dp-ftr .pn { margin-left: auto; white-space: nowrap; }
.dpg .x-anote { font-size: ${o(8.4)}; font-style: italic; color: #444; margin-top: ${o(6)}; }
.dpg .x-simg img { max-height: ${o(40)}; max-width: ${o(120)}; display: block; }
.dpg .x-stamp img { max-height: ${o(70)}; max-width: ${o(70)}; display: block; }
.dpg.dp-fhost { min-height: 0 !important; display: block; }
`,l=`
.dpg.dcl { font-family: "Times New Roman", "Liberation Serif", "DejaVu Serif", Georgia, serif; font-size: ${o(10.3)}; line-height: 1.42; color: #111; }
.dcl .x-bd { padding: ${o(30)} ${o(34)} ${o(10)}; }
.dcl p { margin: ${o(4)} 0; text-align: justify; }
.dcl .c-hb { display: flex; justify-content: space-between; align-items: flex-start; gap: ${o(16)}; padding-bottom: ${o(9)}; border-bottom: 3px double #111; }
.dcl .c-hb > .c-sl { flex: 1; min-width: 0; display: flex; gap: ${o(10)}; align-items: flex-start; }
.dcl .c-hb .c-logo img { display: block; max-height: ${o(46)}; max-width: ${o(110)}; }
.dcl .c-sn { font-size: ${o(13)}; font-weight: 700; letter-spacing: .06em; }
.dcl .c-sd { font-size: ${o(9.4)}; color: #333; margin-top: ${o(3)}; line-height: 1.5; }
.dcl .c-nb { border: 1px solid #111; border-collapse: collapse; font-size: ${o(9.4)}; flex: none; width: auto; }
.dcl .c-nb td { border: .6px solid #111; padding: ${o(2)} ${o(7)}; white-space: nowrap; }
.dcl .c-nb td:first-child { font-variant: small-caps; letter-spacing: .04em; color: #333; }
.dcl .c-nb td:last-child { font-weight: 700; text-align: right; }
.dcl .c-tw { display: flex; align-items: center; gap: ${o(10)}; margin: ${o(16)} 0 ${o(1)}; }
.dcl .c-tw::before, .dcl .c-tw::after { content: ""; flex: 1; border-top: .6px solid #111; }
.dcl .c-tw h3 { margin: 0; font-size: ${o(14)}; letter-spacing: .14em; font-weight: 700; text-align: center; }
.dcl .c-tw + .dp-en { text-align: center; font-size: ${o(9.6)}; margin: 0; }
.dcl .c-sb { text-align: center; font-style: italic; font-size: ${o(9.6)}; color: #333; margin-bottom: ${o(10)}; }
.dcl .c-avs { text-align: center; font-weight: 700; letter-spacing: .1em; font-size: ${o(9.6)}; border-top: .6px solid #111; border-bottom: .6px solid #111; padding: ${o(3)} 0; margin: 0 0 ${o(9)}; }
.dcl .c-avs span { font-weight: 400; letter-spacing: 0; font-style: italic; }
.dcl .c-pr { display: grid; grid-template-columns: 1fr 1fr; border: .6px solid #111; }
.dcl .c-pr > div { padding: ${o(5)} ${o(8)}; min-width: 0; }
.dcl .c-pr > div + div { border-left: .6px solid #111; }
.dcl .c-pr small { display: block; font-variant: small-caps; letter-spacing: .08em; font-size: ${o(9.4)}; color: #333; border-bottom: .6px solid #999; padding-bottom: 1px; margin-bottom: ${o(3)}; }
.dcl .c-pr b { display: block; font-size: ${o(10.6)}; }
.dcl .c-pr span { display: block; font-size: ${o(9.5)}; }
.dcl .c-intro { margin-top: ${o(8)}; }
.dcl table.c-gd { width: 100%; border-collapse: collapse; margin: ${o(9)} 0 0; }
.dcl table.c-gd th, .dcl table.c-gd td { border: .6px solid #111; padding: ${o(3)} ${o(5)}; color: #111; background: #fff; font-size: ${o(9.4)}; vertical-align: top; }
.dcl table.c-gd th { font-weight: 700; text-align: center; border-bottom: 1.4px solid #111; font-size: ${o(8.8)}; line-height: 1.25; }
.dcl table.c-gd td.n { text-align: right; white-space: nowrap; font-variant-numeric: tabular-nums; }
.dcl table.c-gd td.c { text-align: center; }
.dcl .c-tb { display: flex; gap: ${o(14)}; align-items: flex-start; }
.dcl .c-wds { flex: 1; padding-top: ${o(8)}; font-size: ${o(9.8)}; }
.dcl .c-wds small { display: block; font-variant: small-caps; letter-spacing: .08em; color: #333; }
.dcl .c-wds i { font-style: italic; }
.dcl .c-tt { width: ${o(220)}; flex: none; border-collapse: collapse; border: .6px solid #111; border-top: 0; font-size: ${o(9.8)}; }
.dcl table.c-gd + .c-tt { margin-left: auto; }
.dcl .c-tt td { padding: ${o(3)} ${o(7)}; border-bottom: .6px solid #bbb; }
.dcl .c-tt td:last-child { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
.dcl .c-tt tr.b td { border-top: 3px double #111; border-bottom: 0; font-weight: 700; font-size: ${o(11)}; padding: ${o(4)} ${o(7)}; }
.dcl .c-nts { margin-top: ${o(8)}; }
.dcl .c-rk { border: .6px solid #111; margin-top: ${o(8)}; display: grid; grid-template-columns: ${o(110)} 1fr ${o(74)} 1fr; font-size: ${o(9.2)}; }
.dcl .c-rk .h5 { grid-column: 1 / -1; font-variant: small-caps; letter-spacing: .08em; font-size: ${o(9.6)}; padding: ${o(2)} ${o(7)}; border-bottom: .6px solid #111; font-weight: 700; }
.dcl .c-rk span { padding: ${o(1.5)} ${o(7)}; color: #333; }
.dcl .c-rk b { padding: ${o(1.5)} ${o(7)}; font-weight: 400; overflow-wrap: anywhere; }
.dcl .c-rk .w { grid-column: 2 / -1; }
.dcl .c-sgx { display: grid; grid-template-columns: 1fr 1fr; gap: ${o(28)}; margin-top: ${o(16)}; }
.dcl .c-sg small { display: block; font-variant: small-caps; letter-spacing: .08em; font-size: ${o(9.6)}; font-weight: 700; border-bottom: .6px solid #111; padding-bottom: 1px; }
.dcl .c-sg .ps { font-size: ${o(9.4)}; color: #333; margin-top: ${o(3)}; }
.dcl .c-sg .ln2 { display: grid; grid-template-columns: 1fr ${o(46)}; gap: ${o(10)}; align-items: end; margin-top: ${o(6)}; }
.dcl .c-sg .ln2 > div { border-bottom: .6px solid #111; min-height: ${o(30)}; display: flex; align-items: flex-end; }
.dcl .c-sg .ln2 em { width: ${o(46)}; height: ${o(46)}; border: .6px solid #111; border-radius: 50%; display: grid; place-items: center; font-size: ${o(8.5)}; font-style: normal; color: #333; }
.dcl .c-sg .ln2 .x-stamp { width: ${o(46)}; }
.dcl .c-sg .nm2 { font-size: ${o(9.6)}; font-weight: 700; margin-top: ${o(2)}; min-height: 1em; }
.dcl .c-sg .cap { font-size: ${o(8)}; color: #555; font-style: italic; }
.dcl .c-acc { margin-top: ${o(8)}; font-size: ${o(9.8)}; text-align: left; }
.dcl .x-qrb { border: .6px solid #111; padding: ${o(4)}; }
.dcl .dp-ftr { margin: ${o(8)} ${o(34)} ${o(18)}; padding-top: ${o(5)}; border-top: .6px solid #111; color: #333; }
`,u=`
.dpg.dmd { font-family: 'IBM Plex Sans', Arial, sans-serif; font-size: ${o(9.8)}; line-height: 1.45; color: #0f1b33; overflow: hidden; }
.dmd p { margin: 0; }
.dmd .m-band { background: linear-gradient(120deg, var(--dc), color-mix(in srgb, var(--dc) 70%, #3f7dd1)); color: #fff; padding: ${o(16)} ${o(22)} ${o(14)}; display: flex; align-items: center; gap: ${o(12)}; }
.dmd .m-lg { width: ${o(38)}; height: ${o(38)}; flex: none; border-radius: ${o(11)}; background: rgba(255, 255, 255, .18); display: grid; place-items: center; font-weight: 800; font-size: ${o(13)}; border: 1px solid rgba(255, 255, 255, .35); overflow: hidden; }
.dmd .m-lg.img { width: auto; min-width: ${o(38)}; max-width: ${o(110)}; padding: ${o(3)}; background: #fff; }
.dmd .m-lg img { display: block; max-width: 100%; max-height: ${o(32)}; }
.dmd .m-sl { min-width: 0; }
.dmd .m-sl b { display: block; font-size: ${o(12.5)}; }
.dmd .m-sl small { opacity: .85; font-size: ${o(9.5)}; display: block; }
.dmd .m-dn { margin-left: auto; text-align: right; flex: none; }
.dmd .m-dn small { display: block; font-size: ${o(9)}; font-weight: 700; letter-spacing: .12em; opacity: .85; }
.dmd .m-dn b { display: block; font-size: ${o(16)}; letter-spacing: .01em; }
.dmd .m-dn span { font-size: ${o(10)}; opacity: .9; }
.dmd .m-dn .dp-en { color: #fff; opacity: .85; font-size: ${o(8.5)}; }
.dmd .x-bd { padding: ${o(12)} ${o(22)} ${o(6)}; }
.dmd .m-bas { display: flex; align-items: center; gap: ${o(6)}; background: color-mix(in srgb, var(--dc) 8%, #fff); color: var(--dc); border-radius: ${o(8)}; padding: ${o(5)} ${o(9)}; font-weight: 600; font-size: ${o(9.8)}; }
.dmd .m-bas svg { width: ${o(12)}; height: ${o(12)}; flex: none; fill: none; stroke: currentColor; stroke-width: 2; }
.dmd .m-avn { display: flex; align-items: flex-start; gap: ${o(8)}; background: #f5f0ff; border: 1px solid #ddd0fb; color: #4c1d95; border-radius: ${o(9)}; padding: ${o(7)} ${o(10)}; margin-top: ${o(8)}; }
.dmd .m-avn b { display: block; font-size: ${o(10.5)}; color: #5b21b6; letter-spacing: .02em; }
.dmd .m-avn i { font-style: normal; flex: none; width: ${o(20)}; height: ${o(20)}; border-radius: ${o(6)}; background: #6d28d9; color: #fff; display: grid; place-items: center; font-weight: 800; font-size: ${o(9)}; }
.dmd .m-pp { display: grid; grid-template-columns: 1fr 1fr; gap: ${o(8)}; margin-top: ${o(10)}; }
.dmd .m-pp > div { border: 1px solid #e3e8f0; border-radius: ${o(10)}; padding: ${o(8)} ${o(10)}; background: #fafcff; min-width: 0; }
.dmd .m-pp small { display: block; font-size: ${o(8.5)}; font-weight: 800; letter-spacing: .1em; color: var(--dc); margin-bottom: ${o(2)}; text-transform: uppercase; }
.dmd .m-pp b { display: block; font-size: ${o(11)}; }
.dmd .m-pp span { display: block; color: #475569; }
.dmd .m-tx { margin: ${o(9)} 0 0; color: #334155; text-align: justify; }
.dmd table.m-it { width: 100%; border-collapse: separate; border-spacing: 0; margin-top: ${o(10)}; font-size: ${o(9.6)}; border: 1px solid #e3e8f0; border-radius: ${o(9)}; overflow: hidden; }
.dmd table.m-it th { background: color-mix(in srgb, var(--dc) 9%, #fff); color: color-mix(in srgb, var(--dc) 80%, #000); font-size: ${o(8.6)}; letter-spacing: .04em; text-transform: uppercase; padding: ${o(6)}; text-align: left; font-weight: 700; vertical-align: bottom; }
.dmd table.m-it td { padding: ${o(6)}; border-top: 1px solid #eef1f6; vertical-align: top; }
.dmd table.m-it tbody tr:nth-child(odd) td { background: #fbfcfe; }
.dmd table.m-it td.n, .dmd table.m-it th.n { text-align: right; }
.dmd table.m-it td.n { white-space: nowrap; font-variant-numeric: tabular-nums; }
.dmd table.m-it td.c, .dmd table.m-it th.c { text-align: center; }
.dmd .m-tw { display: flex; gap: ${o(10)}; margin-top: ${o(8)}; align-items: flex-start; }
.dmd .m-wd { flex: 1; background: #f6f8fb; border-radius: ${o(9)}; padding: ${o(7)} ${o(10)}; }
.dmd .m-wd small { display: block; font-size: ${o(8.5)}; font-weight: 800; letter-spacing: .08em; color: #64748b; }
.dmd .m-tc { width: ${o(200)}; margin-left: auto; flex: none; border: 1px solid #e3e8f0; border-radius: ${o(10)}; overflow: hidden; }
.dmd .m-tc div { display: flex; justify-content: space-between; gap: ${o(8)}; padding: ${o(4)} ${o(10)}; }
.dmd .m-tc div b { font-weight: 600; font-variant-numeric: tabular-nums; white-space: nowrap; }
.dmd .m-tc div.b { background: var(--dc); color: #fff; font-weight: 800; font-size: ${o(11.5)}; padding: ${o(6)} ${o(10)}; }
.dmd .m-tc div.b b { font-weight: 800; }
.dmd .m-nt { display: flex; gap: ${o(7)}; align-items: flex-start; margin-top: ${o(8)}; color: #334155; }
.dmd .m-nt > i { font-style: normal; flex: none; width: ${o(16)}; height: ${o(16)}; border-radius: 50%; background: color-mix(in srgb, var(--dc) 12%, #fff); color: var(--dc); display: grid; place-items: center; font-weight: 800; font-size: ${o(9)}; }
.dmd .m-rk { margin-top: ${o(9)}; border: 1px solid #e3e8f0; border-radius: ${o(10)}; padding: ${o(7)} ${o(10)}; display: grid; grid-template-columns: auto 1fr auto 1fr; gap: ${o(2)} ${o(8)}; font-size: ${o(9.2)}; }
.dmd .m-rk .h4 { grid-column: 1 / -1; font-size: ${o(8.5)}; font-weight: 800; letter-spacing: .1em; color: var(--dc); margin-bottom: ${o(2)}; }
.dmd .m-rk span { color: #64748b; }
.dmd .m-rk b { overflow-wrap: anywhere; }
.dmd .m-rk .w { grid-column: 2 / -1; }
.dmd .m-sgy { display: grid; grid-template-columns: 1fr 1fr; gap: ${o(10)}; margin-top: ${o(12)}; align-items: start; }
.dmd .m-sgy > div { border: 1px solid #e3e8f0; border-radius: ${o(10)}; padding: ${o(8)} ${o(10)}; display: grid; grid-template-columns: 1fr ${o(46)}; gap: 0 ${o(8)}; align-items: end; }
.dmd .m-sgy small { font-size: ${o(8.5)}; font-weight: 800; letter-spacing: .1em; color: var(--dc); grid-column: 1 / -1; text-transform: uppercase; }
.dmd .m-sgy b { font-size: ${o(10)}; display: block; min-height: 1em; }
.dmd .m-sgy .ln { border-bottom: 1px solid #94a3b8; min-height: ${o(20)}; display: flex; align-items: flex-end; }
.dmd .m-sgy .my { width: ${o(44)}; height: ${o(44)}; border-radius: 50%; border: 1px solid #cbd5e1; display: grid; place-items: center; color: #94a3b8; font-size: ${o(8.5)}; grid-row: 2 / 6; grid-column: 2; }
.dmd .m-sgy .x-stamp { grid-row: 2 / 6; grid-column: 2; }
.dmd .m-sgy .acc { grid-column: 1 / -1; font-size: ${o(8.8)}; color: #475569; margin-top: ${o(4)}; }
.dmd .x-qrb { border: 1px solid #e3e8f0; border-radius: ${o(10)}; padding: ${o(5)} ${o(5)} ${o(3)}; background: #fff; }
.dmd .x-qrb small { color: #475569; font-weight: 600; }
.dmd .dp-ftr { border-top: 2px solid var(--dc); color: #475569; margin-top: ${o(10)}; padding: ${o(7)} ${o(22)} ${o(9)}; background: color-mix(in srgb, var(--dc) 5%, #fff); }
.dmd .dp-ftr .pn { font-weight: 700; color: var(--dc); }
`,d=s+c+l+u,f=(e,t,n)=>{let r=Math.min(1,t/e.w,n/e.h);return`<img src="${i(e.data)}" width="${Math.round(e.w*r)}" height="${Math.round(e.h*r)}" alt="">`},p=(e,t=`p`)=>e?`<${t} class="dp-en" data-pb>${i(e)}</${t}>`:``,m=e=>e===`r`?`n`:e===`c`?`c`:``,h=(e,t)=>`Səhifə ${e} / ${t}`;function g(e){return e.foot?`<div class="dp-ftr" data-foot><span>${i(e.foot.text)}</span>${e.foot.pageNo?`<span class="pn">${h(1,1)}</span>`:``}</div>`:``}var _=e=>e.qr?`<div class="x-qrw" data-pb><div class="x-qrb"><img src="${i(e.qr.data)}" alt="QR"><small>e-qaimə QR kodu</small></div></div>`:`<div class="x-qrw"></div>`,v=e=>e.en?.title?e.en.title.replace(/\s*№\s*\S+$/,``):``,y=e=>e.tin?`${i(e.tinLabel)} ${i(e.tin)}`:``;function b(e){let t=[];e.vatNote&&t.push({html:`<i>${i(e.vatNote)}</i>`,lead:`%`}),e.note&&t.push({html:`<b>Qeyd:</b> ${i(e.note)}`,lead:`✎`});for(let n of e.paras??[])t.push({html:i(n)});return(e.closing||e.en?.closing)&&t.push({html:i(e.closing),en:e.en?.closing}),e.pay&&t.push({html:i(e.pay),lead:`⏱`}),t}function x(e,t){let n=e.sign?`<span class="x-simg">${f(e.sign,160,56)}</span>`:``,r=e.stamp?`<span class="x-stamp">${f(e.stamp,100,100)}</span>`:e.stampText?`<em>M.Y.</em>`:`<span></span>`;return`<div class="c-sg" data-pb><small>${i(e.title)}</small>${p(t,`div`)}<div class="ps">${i(e.position||`Direktor`)}</div><div class="ln2"><div>${n}</div>${r}</div><div class="nm2">${i(e.name??``)}</div><div class="cap">(imza, soyadı, adı, atasının adı)</div></div>`}function S(e){let t=e.en,n=e.seller,r=[],a=[y(n),i(n.address),[n.phone?`Tel.: ${i(n.phone)}`:``,i(n.email)].filter(Boolean).join(` · `)].filter(Boolean).join(`<br>`);if(r.push(`<div class="c-hb" data-pb><div class="c-sl">${e.logo?`<span class="c-logo">${f(e.logo,160,70)}</span>`:``}<div><div class="c-sn">${i(n.name)}</div><div class="c-sd">${a}</div></div></div><table class="c-nb"><tr><td>Sənəd №</td><td>${i(e.no)}</td></tr><tr><td>Tarix</td><td>${i(e.date)}</td></tr><tr><td>Qaimə</td><td>${i(e.serial)}</td></tr></table></div>`),r.push(`<div class="c-tw" data-pb><h3>${i(e.docTitle)}</h3></div>${p(v(e))}`),r.push(`<div class="c-sb" data-pb>№ ${i(e.no)} · ${i(e.basis)}</div>${p(t?.sub)}`),e.avans&&r.push(`<div class="c-avs" data-pb>AVANS ÖDƏNİŞİ ÜZRƏ <span>— mallar təqdim edilməzdən əvvəl alınmış ödəniş</span></div>`),r.push(`<div class="c-pr" data-pb>${e.sides.map(e=>`<div><small>${i(e.role)}</small><b>${i(e.name)}</b>${e.tin?`<span>${y(e)}</span>`:``}${e.address?`<span>${i(e.address)}</span>`:``}</div>`).join(``)}</div>`),e.intro&&r.push(`<p class="c-intro" data-pb>${i(e.intro)}</p>${p(t?.intro)}`),e.table&&r.push(`<table class="c-gd"><thead><tr data-pb>${e.table.head.map(e=>`<th style="width:${e.w}%">${i(e.text)}</th>`).join(``)}</tr></thead><tbody>`+e.table.rows.map(t=>`<tr data-pb>${t.map((t,n)=>`<td class="${m(e.table.head[n].align)}">${i(t)}</td>`).join(``)}</tr>`).join(``)+`</tbody></table>`),e.totals.length||e.words){let t=e.totals.length?`<table class="c-tt">${e.totals.map(e=>`<tr class="${e.bold?`b`:``}"><td>${i(e.k.replace(/:$/,``))}</td><td>${i(e.v)}</td></tr>`).join(``)}</table>`:``;r.push(`<div class="c-tb" data-pb><div class="c-wds">${e.words?`<small>Yekun məbləğ sözlə</small><i>${i(e.words)}</i>`:``}</div>${t}</div>`)}let o=b(e);o.length&&r.push(`<div class="c-nts">${o.map(e=>`${e.html?`<p data-pb>${e.html}</p>`:``}${p(e.en)}`).join(``)}</div>`),e.bank.length&&r.push(C(e,`c-rk`,`<span class="h5">Ödəniş rekvizitləri</span>`)),r.push(`<div class="c-sgx">${x(e.sign.left,t?.signLeft)}${x(e.sign.right,t?.signRight)}</div>`);let s=[e.sign.left,e.sign.right].filter(e=>e.accountant).map(e=>`<p class="c-acc" data-pb>Baş mühasib: ${i(e.accountant)} ______________</p>`);return s.length&&r.push(s.join(``)),(e.footer||t?.footer)&&r.push(`${e.footer?`<p class="x-anote" data-pb>${i(e.footer)}</p>`:``}${t?.footer?`<p class="x-anote dp-en" data-pb>${i(t.footer)}</p>`:``}`),r.push(_(e)),`<div class="dpg dcl" lang="az"><div class="x-bd">${r.join(``)}</div>${g(e)}</div>`}function C(e,t,n){let r=new Set([`Bank`,`Hesablaşma hesabı`]);return`<div class="${t}" data-pb>${n}${e.bank.map(e=>`<span>${i(e.k)}</span><b${r.has(e.k)?` class="w"`:``}>${i(e.v)}</b>`).join(``)}</div>`}var w=`<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8zM14 2v6h6"/></svg>`;function T(e,t){let n=e.stamp?`<span class="x-stamp">${f(e.stamp,66,66)}</span>`:e.stampText?`<span class="my">M.Y.</span>`:``;return`<div data-pb><small>${i(e.title)}</small>${t?`<span class="dp-en" style="grid-column:1/-1">${i(t)}</span>`:``}<span>${i(e.position||`Direktor`)}</span><b>${i(e.name??``)}</b><span class="ln">${e.sign?`<span class="x-simg">${f(e.sign,140,40)}</span>`:``}</span>${n}${e.accountant?`<span class="acc">Baş mühasib: ${i(e.accountant)}</span>`:``}</div>`}function E(e){let n=e.en,r=e.seller,a=[],o=e.logo?`<span class="m-lg img">${f(e.logo,110,32)}</span>`:`<span class="m-lg" aria-hidden="true">${i(t(r.name.replace(/["«»“”]/g,``).replace(/\b(MMC|ASC|QSC|ATSC|İB|LTD|LLC)\b/gi,``),`•`))}</span>`,s=[y(r),i(r.phone)].filter(Boolean).join(` · `),c=`<div class="m-band" data-pb>${o}<span class="m-sl"><b>${i(r.name)}</b>${s?`<small>${s}</small>`:``}${r.address?`<small>${i(r.address)}</small>`:``}</span><span class="m-dn"><small>${i(e.docTitle)}</small>${v(e)?`<span class="dp-en">${i(v(e))}</span>`:``}<b>№ ${i(e.no)}</b><span>${i(e.date)}</span></span></div>`;if(a.push(`<div class="m-bas" data-pb>${w}<span>${i(e.basis)}</span></div>${p(n?.sub)}`),e.avans&&a.push(`<div class="m-avn" data-pb><i>AA</i><span><b>AVANS ÖDƏNİŞİ ÜZRƏ</b>Bu hesab-faktura malların (işlərin, xidmətlərin) təqdim edilməsindən əvvəl alınmış avans ödənişi üzrə tərtib edilmişdir.</span></div>`),a.push(`<div class="m-pp" data-pb>${e.sides.map(e=>`<div><small>${i(e.role)}</small><b>${i(e.name)}</b>${e.tin?`<span>${y(e)}</span>`:``}${e.address?`<span>${i(e.address)}</span>`:``}</div>`).join(``)}</div>`),e.intro&&a.push(`<p class="m-tx" data-pb>${i(e.intro)}</p>${p(n?.intro)}`),e.table&&a.push(`<table class="m-it"><thead><tr data-pb>${e.table.head.map(e=>`<th class="${m(e.align)}" style="width:${e.w}%">${i(e.text)}</th>`).join(``)}</tr></thead><tbody>`+e.table.rows.map(t=>`<tr data-pb>${t.map((t,n)=>`<td class="${m(e.table.head[n].align)}">${i(t)}</td>`).join(``)}</tr>`).join(``)+`</tbody></table>`),e.totals.length||e.words){let t=e.totals.length?`<div class="m-tc">${e.totals.map(e=>`<div class="${e.bold?`b`:``}"><span>${i(e.k.replace(/:$/,``).replace(`ƏDV-siz məbləğ`,`ƏDV-siz`).replace(`Yekun məbləğ`,`Yekun`))}</span><b>${i(e.v)}</b></div>`).join(``)}</div>`:``;a.push(`<div class="m-tw" data-pb>${e.words?`<div class="m-wd"><small>MƏBLƏĞ SÖZLƏ</small>${i(e.words)}</div>`:``}${t}</div>`)}let l=0;for(let t of b(e))t.html&&a.push(`<div class="m-nt" data-pb><i>${t.lead??String(++l)}</i><span>${t.html}</span></div>`),a.push(p(t.en));return e.bank.length&&a.push(C(e,`m-rk`,`<span class="h4">ÖDƏNİŞ REKVİZİTLƏRİ</span>`)),a.push(`<div class="m-sgy">${T(e.sign.left,n?.signLeft)}${T(e.sign.right,n?.signRight)}</div>`),(e.footer||n?.footer)&&a.push(`${e.footer?`<p class="x-anote" data-pb>${i(e.footer)}</p>`:``}${n?.footer?`<p class="x-anote dp-en" data-pb>${i(n.footer)}</p>`:``}`),a.push(_(e)),`<div class="dpg dmd" lang="az" style="--dc:${i(e.color)}">${c}<div class="x-bd">${a.join(``)}</div>${g(e)}</div>`}function D(e){return e.style===`modern`?E(e):S(e)}var O=e({htmlToPdf:()=>M,modelToPdf:()=>j,modelsToPdf:()=>N,pageCuts:()=>k});function k(e,t,n,r){let i=[],a=0,o=[...t].sort((e,t)=>e-t);for(;e-a>(i.length?r:n)+1;){let e=a+(i.length?r:n),t=a;for(let n of o)n>a+24&&n<=e&&(t=n);t<=a&&(t=e),i.push(t),a=t}return i}var A=e=>Promise.all([...e.querySelectorAll(`img`)].map(e=>e.complete?null:new Promise(t=>{e.onload=()=>t(),e.onerror=()=>t()}))),j=e=>M(D(e));async function M(e,t=``){let{jsPDF:r}=await n(async()=>{let{jsPDF:e}=await import(`./jspdf.es.min-BDhsQhkl.js`).then(e=>e.n);return{jsPDF:e}},__vite__mapDeps([0,1,2])),i=new r({orientation:`portrait`,unit:`mm`,format:`a4`,compress:!0});return await P(i,e,t,!0),i.output(`blob`)}async function N(e,t={}){let{jsPDF:r}=await n(async()=>{let{jsPDF:e}=await import(`./jspdf.es.min-BDhsQhkl.js`).then(e=>e.n);return{jsPDF:e}},__vite__mapDeps([0,1,2])),i=new r({orientation:`portrait`,unit:`mm`,format:`a4`,compress:!0});for(let n=0;n<e.length&&!t.signal?.cancelled;n++)await P(i,D(e[n]),``,n===0),t.onProgress?.(n+1,e.length);return i.output(`blob`)}async function P(e,t,i,a){let o=document.createElement(`div`);o.setAttribute(`aria-hidden`,`true`),o.style.cssText=`position:fixed;left:-20000px;top:0;width:794px;z-index:-1;pointer-events:none;`,o.innerHTML=`<style>${d}${i}</style>${t}`,document.body.appendChild(o);try{let t=o.querySelector(`.dpg`);t.style.minHeight=`0`,await document.fonts?.ready,await A(t);let{toCanvas:i}=await n(async()=>{let{toCanvas:e}=await import(`./es-Ct67x-Wl.js`);return{toCanvas:e}},[]),s=t.querySelector(`[data-foot]`),c=0;if(s){let e=s.getBoundingClientRect(),t=getComputedStyle(s);c=Math.ceil(e.height+parseFloat(t.marginTop||`0`)+parseFloat(t.marginBottom||`0`)),s.style.display=`none`}let l=Math.ceil(t.getBoundingClientRect().height),u=t.getBoundingClientRect().top,d=[...t.querySelectorAll(`[data-pb]`)].map(e=>Math.ceil(e.getBoundingClientRect().bottom-u)),f=c?12:0,p=c?r-56-c-f:r-112,m=k(l,d,r-(c?c+f:56),Math.max(200,p)),g=await i(t,{pixelRatio:2,backgroundColor:`#ffffff`,width:794,height:l,style:{minHeight:`0`}}),_=g.width/794,v=210/794,y=[0,...m,l],b=y.slice(1).filter((e,t)=>e-y[t]>=1).length,x=async e=>{if(!s)return null;let n=document.createElement(`div`);n.className=`${t.className} dp-fhost`,n.setAttribute(`style`,t.getAttribute(`style`)??``),n.style.minHeight=`0`;let r=s.cloneNode(!0);r.style.display=``,r.style.marginTop=`0`;let a=r.querySelector(`.pn`);a&&(a.textContent=h(e,b)),n.appendChild(r),o.appendChild(n);try{return await i(n,{pixelRatio:2,backgroundColor:`#ffffff`,width:794,height:Math.ceil(n.getBoundingClientRect().height)})}finally{n.remove()}},S=0;for(let t=0;t<y.length-1;t++){let n=y[t],r=y[t+1];if(r-n<1)continue;(!a||S)&&e.addPage(),S++;let i=document.createElement(`canvas`);i.width=g.width,i.height=Math.max(1,Math.round((r-n)*_));let o=i.getContext(`2d`);o.fillStyle=`#fff`,o.fillRect(0,0,i.width,i.height),o.drawImage(g,0,Math.round(n*_),g.width,i.height,0,0,g.width,i.height),e.addImage(i.toDataURL(`image/jpeg`,.94),`JPEG`,0,t?56*v:0,210,(r-n)*v);let s=await x(S);if(s){let t=s.height/_*v;e.addImage(s.toDataURL(`image/jpeg`,.94),`JPEG`,0,297-t,210,t)}else b>1&&(e.setFontSize(8),e.setTextColor(120,130,150),e.text(`${S} / ${b}`,198,291,{align:`right`}))}}finally{o.remove()}}export{v as a,d as i,j as n,D as o,N as r,O as t};