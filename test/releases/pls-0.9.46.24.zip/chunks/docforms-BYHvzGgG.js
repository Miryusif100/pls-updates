import{s as e}from"./norm-VVsr_jWl.js";import{s as t}from"./calendar-C41VJR2R.js";import{n,t as r}from"./client-wi1dTY10.js";import{n as i,t as a}from"./words-B-cW02Oh.js";import{c as o,m as s,n as c,o as l,r as u,t as d,u as f}from"./dist-CvdOpSZQ.js";import{a as p,i as m,n as h,o as g,r as _,s as v,t as y}from"./azgram-DbpetScm.js";var b=`Times New Roman`,x=`________`,S=[`yanvar`,`fevral`,`mart`,`aprel`,`may`,`iyun`,`iyul`,`avqust`,`sentyabr`,`oktyabr`,`noyabr`,`dekabr`],C=[`January`,`February`,`March`,`April`,`May`,`June`,`July`,`August`,`September`,`October`,`November`,`December`];function w(e){return{a:`cı`,ı:`cı`,o:`cu`,u:`cu`,e:`ci`,ə:`ci`,i:`ci`,ö:`cü`,ü:`cü`}[[...i(e).split(` `).pop()??``].reverse().find(e=>`aıoueəiöü`.includes(e))??`i`]??`ci`}var T=e=>e?`${n(e)}-${w(e.getFullYear())} il`:x,E=e=>e?`${String(e.getDate()).padStart(2,`0`)} ${S[e.getMonth()]} ${e.getFullYear()}-${w(e.getFullYear())} il`:x,D=e=>e?`${e.getDate()} ${C[e.getMonth()]} ${e.getFullYear()}`:x,O=e=>e.toLocaleString(`az-Latn-AZ`,{minimumFractionDigits:2,maximumFractionDigits:2}).replace(/ /g,` `),k=e=>`${e} (${i(Math.round(e))})`;function A(e,t,n){let r=v(e.signerName||``),i=e.signerPosition?y(m(e.signerPosition.toLocaleLowerCase(`az`))):`Direktor`,o={ŞİRKƏT:e.name,ŞİRKƏT_YİYƏLİK:h(e.name,`gen`),ŞİRKƏT_YERLİK:h(e.name,`loc`),ŞİRKƏT_ÇIXIŞLIQ:h(e.name,`abl`),VÖEN:e.tin,ÜNVAN:e.address,TELEFON:e.phone,EPOÇT:e.email,BANK:e.bank,ŞƏHƏR:e.city||`Bakı şəhəri`,RƏHBƏR:r,RƏHBƏR_QISA:r?g(r):x,RƏHBƏR_YÖNLÜK:r?h(g(r),`dat`):x,RƏHBƏR_VƏZİFƏ:i,RƏHBƏR_VƏZİFƏ_K:m(i),RƏHBƏR_VƏZİFƏSİ:p(m(i)),RƏHBƏR_VƏZİFƏ_YİYƏLİK:h(m(i),`gen`),KADR:e.hrName?v(e.hrName):``,KADR_QISA:e.hrName?g(e.hrName):x,KADR_VƏZİFƏ:e.hrPosition||`Kadrlar üzrə mütəxəssis`,NÖMRƏ:n.number||x,TARİX:T(n.date),TARİX_SÖZ:E(n.date),TARİX_EN:D(n.date),İL:String(n.date.getFullYear())};if(t){let e=v(t.name),n=_(t.name);Object.assign(o,{İŞÇİ:e,İŞÇİ_QISA:g(e),İŞÇİ_YÖNLÜK:h(e,`dat`),İŞÇİ_YİYƏLİK:h(e,`gen`),İŞÇİ_ÇIXIŞLIQ:h(e,`abl`),İŞÇİ_TƏSİRLİK:h(e,`acc`),FİN:t.pin,ŞV:t.idCard||x,VƏZİFƏ:t.position,VƏZİFƏ_K:m(t.position),BÖLMƏ:t.unit||x,MAAŞ:O(t.salary),MAAŞ_SÖZLƏ:a(t.salary),İŞƏ_QƏBUL:T(t.start),İŞƏ_QƏBUL_EN:D(t.start),MÜQAVİLƏ_NÖ:t.contractNo||x,MÜQAVİLƏ_TARİXİ:T(t.contractDate),DOĞUM:T(t.birthday),NORMA:String(t.vacNorm||x),QALIQ:t.balance==null?x:String(Math.round(t.balance*100)/100),STAJ:t.staj||x,İŞ_REJİMİ:t.workMode||x,EN_MR:n?`Ms.`:`Mr.`,EN_HIS:n?`Her`:`His`,EN_HIS_L:n?`her`:`his`,EN_HE:n?`She`:`He`})}return o}function j(e,t){return e.replace(/\{([A-ZƏÖÜĞIİŞÇ_0-9]+)\}/g,(e,n)=>t[n]==null?x:t[n])}function M(e,t){let n=[];for(let r of e.replace(/\r/g,``).split(`
`)){let e=r.trimEnd().trim();if(!e){n.push({t:`blank`});continue}if(e===`[[BAŞLIQ]]`){n.push({t:`head`});continue}if(e===`[[NÖMRƏ]]`){n.push({t:`num`});continue}if(e===`[[İMZA]]`){n.push({t:`sign`,who:`head`});continue}if(e===`[[İMZA_KADR]]`){n.push({t:`sign`,who:`hr`});continue}if(e===`[[İMZA_İŞÇİ]]`){n.push({t:`sign`,who:`employee`});continue}if(e===`[[İMZA_İKİ]]`){n.push({t:`sign`,who:`both`});continue}if(e===`[[TANIŞ]]`){n.push({t:`ack`});continue}let i=/^(##|#|!|>|-)\s+(.*)$/.exec(e),a=i?{"#":`title`,"##":`sub`,"!":`bold`,">":`right`,"-":`left`}[i[1]]:`body`,o=j(i?i[2]:e,t);o.trim()&&o.split(`
`).map(e=>e.trim()).filter(Boolean).forEach((e,t)=>n.push({t:`p`,kind:t&&a===`body`?`left`:a,text:e}))}return n}var N=(e,t={})=>new s({text:e,bold:t.bold,italics:t.italic,size:(t.size??12)*2,font:b}),P=(e,t={})=>new o({children:e,alignment:t.align??d.JUSTIFIED,spacing:{after:t.after??120,before:t.before??0,line:300},indent:t.indent?{firstLine:567}:void 0,tabStops:t.tabs?[{type:f.CENTER,position:4819},{type:f.RIGHT,position:9638}]:void 0,border:t.border?{bottom:{style:c.SINGLE,size:8,color:`111111`,space:4}}:void 0});function F(e,t,n){let r=n.lang===`en`;if(e===`both`)return[P([N(`İŞƏGÖTÜRƏN`,{bold:!0}),N(`	`),N(`	İŞÇİ`,{bold:!0})],{tabs:!0,align:d.LEFT,before:240}),P([N(t.ŞİRKƏT??``),N(`	`),N(`\t${t.İŞÇİ??``}`)],{tabs:!0,align:d.LEFT}),P([N(`${t.RƏHBƏR_VƏZİFƏ} ${t.RƏHBƏR_QISA}`),N(`	`),N(`\tFİN ${t.FİN??``}`)],{tabs:!0,align:d.LEFT}),P([N(`İmza: ______________`),N(`	`),N(`	İmza: ______________`)],{tabs:!0,align:d.LEFT}),...n.seal===!1?[]:[P([N(`M.Y.`,{size:10})],{align:d.LEFT})]];if(e===`employee`)return[P([N(r?`Signature: ______________`:`İmza: ______________`),N(`	`),N(`\t${t.İŞÇİ_QISA??``}`,{bold:!0})],{tabs:!0,align:d.LEFT,before:360}),P([N(r?`Date: ___ ____________ 20__`:`Tarix: «___» ____________ 20___-ci il`)],{align:d.LEFT})];let i=e===`hr`?t.KADR_VƏZİFƏ:r?`Director`:t.RƏHBƏR_VƏZİFƏ,a=e===`hr`?t.KADR_QISA:t.RƏHBƏR_QISA;return[P([N(i??``,{bold:!0}),N(`	______________`),N(`\t${a??``}`,{bold:!0})],{tabs:!0,align:d.LEFT,before:480}),...e===`head`&&n.seal!==!1?[P([N(r?`Seal`:`M.Y.`,{size:10})],{align:d.LEFT})]:[]]}function ee(e,t){let n=t.vars,r=[];for(let i of e)if(i.t===`blank`)r.push(new o({children:[]}));else if(i.t===`head`)r.push(P([N(n.ŞİRKƏT??``,{bold:!0,size:13})],{align:d.CENTER,after:40})),r.push(P([N([`VÖEN ${n.VÖEN??``}`,n.ÜNVAN,n.TELEFON].filter(Boolean).join(` · `),{size:10})],{align:d.CENTER,after:240,border:!0}));else if(i.t===`num`)r.push(P([N(`№ ${n.NÖMRƏ??``}`),N(`\t${n.ŞƏHƏR??``}`),N(`\t${t.lang===`en`?n.TARİX_EN:n.TARİX_SÖZ}`)],{tabs:!0,align:d.LEFT,after:240}));else if(i.t===`sign`)r.push(...F(i.who,n,t));else if(i.t===`ack`)r.push(P([N(`Əmrlə tanış oldum: ______________ `),N(n.İŞÇİ_QISA??``),N(`    «___» ____________ 20___-ci il`)],{align:d.LEFT,before:360}));else{let e=i.kind;e===`title`?r.push(P([N(i.text,{bold:!0,size:14})],{align:d.CENTER,before:120,after:60})):e===`sub`?r.push(P([N(i.text,{bold:!0})],{align:d.CENTER,after:120})):e===`bold`?r.push(P([N(i.text,{bold:!0})],{align:d.LEFT,after:160})):e===`right`?r.push(P([N(i.text)],{align:d.RIGHT,after:0})):e===`left`?r.push(P([N(i.text)],{align:d.LEFT})):r.push(P([N(i.text)],{indent:!0}))}return r}async function te(e,t){let n=new u({creator:`PLS`,styles:{default:{document:{run:{font:b,size:24}}}},sections:[{properties:{page:{margin:{top:1134,bottom:1134,left:1418,right:850}}},children:ee(M(e,t.vars),t)}]});return l.toBlob(n)}var ne={ə:`e`,Ə:`E`,ı:`i`,İ:`I`,ö:`o`,Ö:`O`,ü:`u`,Ü:`U`,ş:`s`,Ş:`S`,ç:`c`,Ç:`C`,ğ:`g`,Ğ:`G`},re=e=>e.replace(/[əƏıİöÖüÜşŞçÇğĞ]/g,e=>ne[e]??e).replace(/[^A-Za-z0-9.-]+/g,`_`).replace(/^_+|_+$/g,``),ie=[{id:`emr`,name:`Əmrlər`,color:`#B45309`,tint:`#FDF1E3`},{id:`erize`,name:`Ərizələr (işçinin adından)`,color:`#1D4F91`,tint:`#E8F0FB`},{id:`muqavile`,name:`Müqavilə və əlavələr`,color:`#0F766E`,tint:`#E3F5F2`},{id:`arayis`,name:`Arayışlar`,color:`#BE185D`,tint:`#FCE7F1`},{id:`akt`,name:`Aktlar və digər`,color:`#6B3FA0`,tint:`#F1EAFA`}],ae=e=>`${e.getFullYear()}-${String(e.getMonth()+1).padStart(2,`0`)}-${String(e.getDate()).padStart(2,`0`)}`,I={date:(e,t,n,r)=>({id:e,label:t,type:`date`,def:n?e=>{let t=n(e);return t?ae(t):``}:void 0,hint:r}),text:(e,t,n,r,i=!1)=>({id:e,label:t,type:`text`,def:n,hint:r,wide:i}),area:(e,t,n,r)=>({id:e,label:t,type:`textarea`,def:n,hint:r,wide:!0}),days:(e,t,n)=>({id:e,label:t,type:`days`,def:n}),money:(e,t,n)=>({id:e,label:t,type:`money`,def:n}),sel:(e,t,n,r)=>({id:e,label:t,type:`select`,options:n,def:r??n[0].value})},L=e=>e.today,R=(t=new Date)=>{let n=e(`emek.orta-ay-gunleri`,t);return typeof n==`number`&&n>0?n:null},z=(e,t,n)=>{let r=R(n);return r?Math.round(Math.max(0,e)*t/r*100)/100:0},B=e=>String(z(Math.round(e.balance??0),e.salary)),V=e=>{let t=new Date(e.today);return t.setDate(t.getDate()+((8-t.getDay())%7||7)),t},H=[{value:`1`,label:`Əmək məzuniyyəti (əsas və əlavə)`,text:`əmək məzuniyyəti`},{value:`6`,label:`Ödənişsiz məzuniyyət`,text:`ödənişsiz məzuniyyət`},{value:`4`,label:`Sosial məzuniyyət`,text:`sosial məzuniyyət`},{value:`2`,label:`Təhsil məzuniyyəti`,text:`təhsil məzuniyyəti`},{value:`3`,label:`Yaradıcılıq məzuniyyəti`,text:`yaradıcılıq məzuniyyəti`},{value:`5`,label:`Qismən ödənişli məzuniyyət`,text:`qismən ödənişli sosial məzuniyyət`}],U=`[[BAŞLIQ]]
# ƏMR
[[NÖMRƏ]]`,W=`> {ŞİRKƏT_YİYƏLİK}
> {RƏHBƏR_VƏZİFƏSİ} {RƏHBƏR_YÖNLÜK}
> {VƏZİFƏ} vəzifəsində çalışan
> {İŞÇİ_ÇIXIŞLIQ}

# ƏRİZƏ
`,G=`
[[İMZA_İŞÇİ]]`,K=`
[[İMZA]]
[[TANIŞ]]`,q=[{id:`emr-qebul`,cat:`emr`,name:`İşə qəbul haqqında əmr`,desc:`Əmək müqaviləsi əsasında`,numbered:!0,fmt:`{SIRA}-Q`,params:[I.date(`BAŞLAMA`,`İşə başlama tarixi`,e=>e.start??e.today),I.text(`SINAQ`,`Sınaq müddəti`,`3 (üç) ay`,`Boş qalsa — sınaq müddəti yoxdur`),I.text(`ƏSAS`,`Əsas`,e=>`${e.contractDate?T(e.contractDate)+` tarixli `:``}${e.contractNo?e.contractNo+` nömrəli `:``}əmək müqaviləsi`,void 0,!0)],text:`${U}
! İşə qəbul haqqında
Azərbaycan Respublikası Əmək Məcəlləsinə və tərəflər arasında bağlanmış əmək müqaviləsinə əsasən,
## ƏMR EDİRƏM:
1. {İŞÇİ} (FİN {FİN}) {BAŞLAMA} tarixdən {VƏZİFƏ} vəzifəsinə işə qəbul edilsin.
2. Aylıq vəzifə maaşı {MAAŞ} ({MAAŞ_SÖZLƏ}) müəyyən edilsin.
3. Sınaq müddəti: {SINAQ}.
4. Mühasibatlığa tapşırılsın ki, əməkhaqqının hesablanmasını qanunvericiliyə uyğun təmin etsin.
- Əsas: {ƏSAS}.
${K}`},{id:`emr-mezuniyyet`,cat:`emr`,name:`Məzuniyyət verilməsi haqqında əmr`,desc:`6 növ, iş ili və qalıqla`,numbered:!0,fmt:`{SIRA}-M`,params:[I.sel(`NÖV`,`Məzuniyyətin növü`,H),I.date(`BAŞLAMA`,`Başlama tarixi`,V),I.days(`GÜN`,`Müddət (təqvim günü)`,`14`),I.text(`İŞ_İLİ`,`İş ili`,e=>Y(e),`Əmək məzuniyyəti üçün`),I.text(`ƏSAS`,`Əsas`,e=>`işçinin ${T(e.today)} tarixli ərizəsi`,void 0,!0)],text:`${U}
! Məzuniyyət verilməsi haqqında
Azərbaycan Respublikası Əmək Məcəlləsinə və işçinin ərizəsinə əsasən,
## ƏMR EDİRƏM:
1. {VƏZİFƏ} vəzifəsində çalışan {İŞÇİ_YÖNLÜK} {İŞ_İLİ} iş ili üçün {BAŞLAMA} tarixdən {BİTMƏ} tarixədək {GÜN_SÖZLƏ} təqvim günü müddətinə {NÖV} verilsin.
2. İşçi {İŞƏ_ÇIXMA} tarixdən işə çıxsın.
3. Mühasibatlığa tapşırılsın ki, məzuniyyət haqqını qanunvericiliyə uyğun hesablayıb ödəsin.
- Əsas: {ƏSAS}.
${K}`},{id:`emr-geri-cagirma`,cat:`emr`,name:`Məzuniyyətdən geri çağırma`,desc:`İşçinin razılığı ilə`,numbered:!0,fmt:`{SIRA}-K`,params:[I.text(`MƏZ_ƏMR`,`Məzuniyyət əmri (№ və tarix)`,``,`məs. 44-M, 06.10.2026`),I.date(`TARİXDƏN`,`İşə çağırılır`,L),I.days(`QALAN`,`İstifadə olunmamış gün`,`5`),I.text(`SƏBƏB`,`Səbəb`,`istehsalat zərurəti`,void 0,!0)],text:`${U}
! Məzuniyyətdən geri çağırma haqqında
{SƏBƏB} ilə əlaqədar, Azərbaycan Respublikası Əmək Məcəlləsinə əsasən və işçinin razılığı ilə,
## ƏMR EDİRƏM:
1. {MƏZ_ƏMR} nömrəli əmrlə məzuniyyətdə olan {VƏZİFƏ} {İŞÇİ} {TARİXDƏN} tarixdən məzuniyyətdən geri çağırılsın.
2. Məzuniyyətin istifadə olunmamış {QALAN_SÖZLƏ} təqvim günü işçiyə sonradan, tərəflərin razılaşdırdığı vaxtda verilsin.
- Əsas: işçinin razılığı.
${K}`},{id:`emr-ezamiyye`,cat:`emr`,name:`Ezamiyyə haqqında əmr`,desc:`Ölkədaxili və ya xarici`,numbered:!0,fmt:`{SIRA}-E`,params:[I.sel(`NÖV`,`Ezamiyyənin növü`,[{value:`d`,label:`Ölkədaxili`,text:`ölkədaxili`},{value:`x`,label:`Xarici`,text:`xarici`}]),I.text(`YER`,`Ezamiyyə yeri (şəhər, təşkilat)`,`Gəncə şəhəri`),I.date(`BAŞLAMA`,`Başlama`,V),I.days(`GÜN`,`Müddət (gün)`,`3`),I.area(`MƏQSƏD`,`Ezamiyyənin məqsədi`,`xidməti tapşırığın yerinə yetirilməsi`),I.text(`ƏSAS`,`Əsas`,`xidməti məruzə`,void 0,!0)],text:`${U}
! Ezamiyyə haqqında
Xidməti zərurətlə əlaqədar, Azərbaycan Respublikası Əmək Məcəlləsinə əsasən,
## ƏMR EDİRƏM:
1. {VƏZİFƏ} {İŞÇİ} {MƏQSƏD} məqsədilə {BAŞLAMA} tarixdən {BİTMƏ} tarixədək {GÜN_SÖZLƏ} gün müddətinə {NÖV} ezamiyyətə göndərilsin. Ezamiyyə yeri: {YER}.
2. Mühasibatlığa tapşırılsın ki, ezamiyyə xərclərini qanunvericiliklə müəyyən edilmiş normalar üzrə ödəsin.
3. Ezamiyyədən qayıtdıqdan sonra 3 (üç) iş günü ərzində avans hesabatı və görülmüş iş barədə hesabat təqdim edilsin.
- Əsas: {ƏSAS}.
${K}`},{id:`emr-xitam`,cat:`emr`,name:`Əmək müqaviləsinə xitam verilməsi haqqında əmr`,desc:`Maddə üzrə, kompensasiya ilə`,numbered:!0,fmt:`{SIRA}-X`,params:[I.date(`TARİXDƏN`,`Xitam tarixi`,L),I.text(`MADDƏ`,`Hüquqi əsas (Əmək Məcəlləsinin maddəsi)`,`68-ci maddəsinin 1-ci hissəsinə`,`məs. 68-ci maddəsinin 1-ci hissəsinə (işçinin təşəbbüsü)`,!0),I.days(`KOMP`,`İstifadə olunmamış məzuniyyət (gün)`,e=>String(Math.max(0,Math.round(e.balance??0)))),{...I.money(`MƏBLƏĞ`,`Kompensasiya (ilkin hesab), ₼`,B),hint:`gün × aylıq əməkhaqqı ÷ ayın orta günləri (Normativlər) — mühasibatlıq dəqiqləşdirir`},I.text(`ƏSAS`,`Əsas`,e=>`işçinin ${T(e.today)} tarixli ərizəsi`,void 0,!0)],text:`${U}
! Əmək müqaviləsinə xitam verilməsi haqqında
Azərbaycan Respublikası Əmək Məcəlləsinin {MADDƏ} əsasən,
## ƏMR EDİRƏM:
1. {VƏZİFƏ} vəzifəsində çalışan {İŞÇİ} (FİN {FİN}) ilə bağlanmış {MÜQAVİLƏ_NÖ} nömrəli əmək müqaviləsinə {TARİXDƏN} tarixdən xitam verilsin.
2. Mühasibatlığa tapşırılsın ki, işçi ilə tam haqq-hesab çəkilsin, istifadə olunmamış {KOMP_SÖZLƏ} təqvim günü məzuniyyətə görə kompensasiya (ilkin hesablanmış məbləğ {MƏBLƏĞ} ({MƏBLƏĞ_SÖZLƏ})) ödənilsin.
3. Kadrlar bölməsinə tapşırılsın ki, əmək müqaviləsinə xitam verilməsi barədə məlumatı elektron sistemə vaxtında daxil etsin.
- Əsas: {ƏSAS}.
${K}`},{id:`emr-kecirme`,cat:`emr`,name:`Başqa işə keçirmə haqqında əmr`,desc:`Vəzifə və əməkhaqqı`,numbered:!0,fmt:`{SIRA}-K`,params:[I.text(`YENİ_VƏZİFƏ`,`Yeni vəzifə`,``),I.money(`YENİ_MAAŞ`,`Yeni aylıq əməkhaqqı`,e=>String(e.salary)),I.date(`TARİXDƏN`,`Tarixdən`,V),I.text(`ƏSAS`,`Əsas`,`işçinin razılığı və əmək müqaviləsinə əlavə`,void 0,!0)],text:`${U}
! Başqa işə keçirmə haqqında
Azərbaycan Respublikası Əmək Məcəlləsinə əsasən və işçinin razılığı ilə,
## ƏMR EDİRƏM:
1. {VƏZİFƏ} vəzifəsində çalışan {İŞÇİ} {TARİXDƏN} tarixdən {YENİ_VƏZİFƏ} vəzifəsinə keçirilsin.
2. Aylıq əməkhaqqı {YENİ_MAAŞ} ({YENİ_MAAŞ_SÖZLƏ}) müəyyən edilsin.
3. Əmək müqaviləsinə müvafiq dəyişiklik edilsin.
- Əsas: {ƏSAS}.
${K}`},{id:`emr-maas`,cat:`emr`,name:`Əməkhaqqının dəyişdirilməsi haqqında əmr`,desc:`Artım və ya dəyişiklik`,numbered:!0,fmt:`{SIRA}-K`,params:[I.money(`YENİ_MAAŞ`,`Yeni aylıq əməkhaqqı`,e=>String(e.salary)),I.date(`TARİXDƏN`,`Tarixdən`,e=>new Date(e.today.getFullYear(),e.today.getMonth()+1,1)),I.text(`ƏSAS`,`Əsas`,`əmək müqaviləsinə əlavə`,void 0,!0)],text:`${U}
! Əməkhaqqının dəyişdirilməsi haqqında
Azərbaycan Respublikası Əmək Məcəlləsinə əsasən,
## ƏMR EDİRƏM:
1. {VƏZİFƏ} {İŞÇİ} üçün {TARİXDƏN} tarixdən aylıq əməkhaqqı {MAAŞ} manatdan {YENİ_MAAŞ} ({YENİ_MAAŞ_SÖZLƏ}) manata dəyişdirilsin.
2. Mühasibatlığa tapşırılsın ki, əməkhaqqının hesablanmasını bu əmrə uyğun aparsın.
- Əsas: {ƏSAS}.
${K}`},{id:`emr-mukafat`,cat:`emr`,name:`Mükafatlandırma haqqında əmr`,desc:`Birdəfəlik mükafat`,numbered:!0,fmt:`{SIRA}-K`,params:[I.money(`MƏBLƏĞ`,`Mükafatın məbləği`,`500`),I.area(`SƏBƏB`,`Nəyə görə`,`əmək vəzifələrini nümunəvi yerinə yetirdiyinə görə`)],text:`${U}
! Mükafatlandırma haqqında
Azərbaycan Respublikası Əmək Məcəlləsinə əsasən,
## ƏMR EDİRƏM:
1. {VƏZİFƏ} {İŞÇİ} {SƏBƏB} {MƏBLƏĞ} ({MƏBLƏĞ_SÖZLƏ}) məbləğində birdəfəlik pul mükafatı ilə mükafatlandırılsın.
2. Mühasibatlığa tapşırılsın ki, mükafatı qanunvericiliyə uyğun hesablayıb ödəsin.
${K}`},{id:`emr-tenbeh`,cat:`emr`,name:`İntizam tənbehi haqqında əmr`,desc:`İzahat alındıqdan sonra`,numbered:!0,fmt:`{SIRA}-K`,params:[I.sel(`TƏNBEH`,`Tənbeh növü`,[{value:`t`,label:`Töhmət`,text:`töhmət`},{value:`ş`,label:`Şiddətli töhmət`,text:`şiddətli töhmət`}]),I.area(`HAL`,`Pozuntu (nə, nə vaxt)`,e=>`${T(e.today)} tarixdə işə üzrsüz gecikməsi`),I.text(`İZAHAT`,`İşçinin izahatı`,e=>`${T(e.today)} tarixli izahat`,void 0,!0)],text:`${U}
! İntizam tənbehi verilməsi haqqında
{HAL} ilə əlaqədar əmək intizamının pozulmasına görə, işçinin izahatı nəzərə alınmaqla, Azərbaycan Respublikası Əmək Məcəlləsinə əsasən,
## ƏMR EDİRƏM:
1. {VƏZİFƏ} {İŞÇİ_YÖNLÜK} {TƏNBEH} intizam tənbehi verilsin.
- Əsas: {İZAHAT}.
${K}`},{id:`emr-evezetme`,cat:`emr`,name:`Əvəzetmə (həvalə) haqqında əmr`,desc:`Müvəqqəti yoxluq zamanı`,numbered:!0,fmt:`{SIRA}-K`,params:[I.text(`ƏVƏZ_OLUNAN`,`Kimi əvəz edir (yiyəlik halında)`,``,`məs. baş mühasib L.R. Həsənovanın`,!0),I.date(`BAŞLAMA`,`Başlama`,V),I.date(`SON`,`Bitmə`,e=>r(V(e),13)),I.text(`ƏLAVƏ`,`Əlavə ödəniş`,`vəzifə maaşları arasındakı fərq qədər`,void 0,!0)],text:`${U}
! Vəzifənin müvəqqəti həvalə edilməsi haqqında
Azərbaycan Respublikası Əmək Məcəlləsinə əsasən və işçinin razılığı ilə,
## ƏMR EDİRƏM:
1. {ƏVƏZ_OLUNAN} müvəqqəti yoxluğu dövründə, {BAŞLAMA} tarixdən {SON} tarixədək, həmin vəzifənin icrası {VƏZİFƏ} {İŞÇİ_YÖNLÜK} öz əsas işindən ayrılmadan həvalə edilsin.
2. Əvəzetməyə görə {ƏLAVƏ} əlavə ödənilsin.
${K}`},{id:`emr-rejim`,cat:`emr`,name:`İş rejiminin dəyişdirilməsi haqqında əmr`,desc:`Natamam iş vaxtı, növbə`,numbered:!0,fmt:`{SIRA}-K`,params:[I.text(`REJİM`,`Yeni iş rejimi`,`natamam iş vaxtı (gündə 4 saat, həftədə 20 saat)`,void 0,!0),I.date(`TARİXDƏN`,`Tarixdən`,V),I.text(`ƏSAS`,`Əsas`,`işçinin ərizəsi`,void 0,!0)],text:`${U}
! İş rejiminin dəyişdirilməsi haqqında
Azərbaycan Respublikası Əmək Məcəlləsinə əsasən və tərəflərin razılığı ilə,
## ƏMR EDİRƏM:
1. {VƏZİFƏ} {İŞÇİ} üçün {TARİXDƏN} tarixdən {REJİM} iş rejimi müəyyən edilsin.
2. Əməkhaqqı faktiki işlənmiş vaxta mütənasib hesablansın.
- Əsas: {ƏSAS}.
${K}`},{id:`emr-kompensasiya`,cat:`emr`,name:`Məzuniyyətə görə kompensasiya haqqında əmr`,desc:`İstifadə olunmamış günlər`,numbered:!0,fmt:`{SIRA}-K`,params:[I.days(`GÜN`,`Gün sayı`,e=>String(Math.max(0,Math.round(e.balance??0)))),{...I.money(`MƏBLƏĞ`,`Kompensasiya (ilkin hesab), ₼`,B),hint:`gün × aylıq əməkhaqqı ÷ ayın orta günləri (Normativlər)`},I.text(`İŞ_İLİ`,`İş ili`,e=>Y(e)),I.text(`ƏSAS`,`Əsas`,`əmək müqaviləsinə xitam verilməsi`,void 0,!0)],text:`${U}
! İstifadə olunmamış məzuniyyətə görə kompensasiya ödənilməsi haqqında
Azərbaycan Respublikası Əmək Məcəlləsinə əsasən,
## ƏMR EDİRƏM:
1. {VƏZİFƏ} {İŞÇİ_YÖNLÜK} {İŞ_İLİ} iş ili üzrə istifadə olunmamış {GÜN_SÖZLƏ} təqvim günü əmək məzuniyyətinə görə pul kompensasiyası ödənilsin.
2. Mühasibatlığa tapşırılsın ki, kompensasiyanı orta əməkhaqqına görə hesablayıb ödəsin (ilkin hesablanmış məbləğ {MƏBLƏĞ} ({MƏBLƏĞ_SÖZLƏ})).
- Əsas: {ƏSAS}.
${K}`},{id:`erize-qebul`,cat:`erize`,name:`İşə qəbul haqqında ərizə`,desc:`Namizədin adından`,numbered:!1,params:[I.date(`BAŞLAMA`,`İşə başlama`,e=>e.start??e.today)],text:`> {ŞİRKƏT_YİYƏLİK}
> {RƏHBƏR_VƏZİFƏSİ} {RƏHBƏR_YÖNLÜK}
> {İŞÇİ_ÇIXIŞLIQ}
> FİN {FİN}

# ƏRİZƏ
Xahiş edirəm, məni {BAŞLAMA} tarixdən {VƏZİFƏ} vəzifəsinə işə qəbul edəsiniz.
${G}`},{id:`erize-mezuniyyet`,cat:`erize`,name:`Məzuniyyət haqqında ərizə`,desc:`Əmrlə birlikdə hazırlanır`,numbered:!1,params:[I.sel(`NÖV`,`Məzuniyyətin növü`,H),I.date(`BAŞLAMA`,`Başlama`,V),I.days(`GÜN`,`Müddət (təqvim günü)`,`14`),I.text(`İŞ_İLİ`,`İş ili`,e=>Y(e))],text:`${W}Xahiş edirəm, mənə {İŞ_İLİ} iş ili üçün {BAŞLAMA} tarixdən {GÜN_SÖZLƏ} təqvim günü müddətinə {NÖV} verəsiniz.
${G}`},{id:`erize-odenissiz`,cat:`erize`,name:`Ödənişsiz məzuniyyət haqqında ərizə`,desc:`Ailə vəziyyəti və s.`,numbered:!1,params:[I.date(`BAŞLAMA`,`Başlama`,V),I.days(`GÜN`,`Müddət (gün)`,`3`),I.text(`SƏBƏB`,`Səbəb`,`ailə vəziyyəti ilə əlaqədar`,void 0,!0)],text:`${W}Xahiş edirəm, {SƏBƏB} mənə {BAŞLAMA} tarixdən {GÜN_SÖZLƏ} təqvim günü müddətinə ödənişsiz məzuniyyət verəsiniz.
${G}`},{id:`erize-cixis`,cat:`erize`,name:`İşdən çıxma haqqında ərizə`,desc:`Öz arzusu ilə`,numbered:!1,params:[I.date(`TARİXDƏN`,`Son iş günü`,e=>r(e.today,30))],text:`${W}Xahiş edirəm, öz arzumla {TARİXDƏN} tarixdən mənimlə bağlanmış əmək müqaviləsinə xitam verəsiniz.
${G}`},{id:`erize-kecirme`,cat:`erize`,name:`Başqa vəzifəyə keçirilmə haqqında ərizə`,desc:`Keçirmə əmri üçün`,numbered:!1,params:[I.text(`YENİ_VƏZİFƏ`,`Yeni vəzifə`,``),I.date(`TARİXDƏN`,`Tarixdən`,V)],text:`${W}Xahiş edirəm, məni {TARİXDƏN} tarixdən {YENİ_VƏZİFƏ} vəzifəsinə keçirəsiniz.
${G}`},{id:`erize-arayis`,cat:`erize`,name:`Arayış tələbi haqqında ərizə`,desc:`İş yerindən arayış üçün`,numbered:!1,params:[I.text(`YER`,`Təqdim ediləcək yer`,`tələb olunan yerə`,void 0,!0)],text:`${W}Xahiş edirəm, {YER} təqdim etmək üçün mənə iş yerindən arayış verəsiniz.
${G}`},{id:`erize-kart`,cat:`erize`,name:`Əməkhaqqının karta köçürülməsi haqqında ərizə`,desc:`Bank rekvizitləri ilə`,numbered:!1,params:[I.text(`BANK_ADI`,`Bank`,``),I.text(`HESAB`,`Kart / hesab nömrəsi (IBAN)`,``,void 0,!0)],text:`${W}Xahiş edirəm, əməkhaqqımı və digər ödənişləri aşağıdakı hesabıma köçürəsiniz: {BANK_ADI}, hesab (IBAN) {HESAB}.
${G}`},{id:`muq-layihe`,cat:`muqavile`,name:`Əmək müqaviləsi (layihə)`,desc:`Əsas şərtlər — portaldakı ilə tutuşdurun`,numbered:!1,params:[I.date(`BAŞLAMA`,`Başlama`,e=>e.start??e.today),I.text(`MÜDDƏT`,`Müddət`,`müddətsiz`),I.text(`SINAQ`,`Sınaq müddəti`,`3 (üç) ay`),I.text(`İŞ_VAXTI`,`İş vaxtı`,`həftədə 40 saat, 5 günlük iş həftəsi`,void 0,!0)],text:`[[BAŞLIQ]]
# ƏMƏK MÜQAVİLƏSİ
[[NÖMRƏ]]
{ŞİRKƏT} (VÖEN {VÖEN}), {RƏHBƏR_VƏZİFƏ_K} {RƏHBƏR} vasitəsilə (bundan sonra — "İşəgötürən"), bir tərəfdən, və {İŞÇİ} (FİN {FİN}, şəxsiyyət vəsiqəsi {ŞV}) (bundan sonra — "İşçi"), digər tərəfdən, Azərbaycan Respublikasının Əmək Məcəlləsinə uyğun olaraq bu müqaviləni bağladılar.
! 1. Müqavilənin predmeti
1.1. İşçi {BAŞLAMA} tarixdən {VƏZİFƏ} vəzifəsinə işə qəbul edilir. İş yeri: {ÜNVAN}.
1.2. Müqavilənin müddəti: {MÜDDƏT}. Sınaq müddəti: {SINAQ}.
! 2. Əmək şəraiti
2.1. İş vaxtı: {İŞ_VAXTI}. İstirahət və bayram günləri qanunvericiliyə uyğundur.
2.2. İllik əsas məzuniyyət {NORMA} təqvim günüdür.
! 3. Əməyin ödənilməsi
3.1. Aylıq əməkhaqqı {MAAŞ} ({MAAŞ_SÖZLƏ}) təşkil edir və ayda bir dəfədən az olmayaraq ödənilir.
! 4. Tərəflərin hüquq və vəzifələri
4.1. İşçi əmək funksiyasını vicdanla yerinə yetirir, əmək intizamına və əməyin mühafizəsi qaydalarına əməl edir.
4.2. İşəgötürən təhlükəsiz əmək şəraiti yaradır, əməkhaqqını vaxtında ödəyir, icbari sosial sığorta haqlarını köçürür.
! 5. Yekun müddəalar
5.1. Müqaviləyə dəyişiklik tərəflərin razılığı ilə yazılı formada edilir. Müqavilə elektron informasiya sisteminə daxil edildiyi gündən qüvvəyə minir.
[[İMZA_İKİ]]`},{id:`muq-deyisiklik`,cat:`muqavile`,name:`Müqaviləyə dəyişiklik (əlavə razılaşma)`,desc:`Maaş, vəzifə, iş rejimi`,numbered:!1,params:[I.area(`DƏYİŞİKLİK`,`Dəyişiklik`,e=>`Müqavilənin əməkhaqqı bəndi aşağıdakı redaksiyada verilsin: "Aylıq əməkhaqqı ${O(e.salary)} manat təşkil edir."`),I.date(`TARİXDƏN`,`Qüvvəyə minir`,e=>new Date(e.today.getFullYear(),e.today.getMonth()+1,1))],text:`[[BAŞLIQ]]
# ƏMƏK MÜQAVİLƏSİNƏ ƏLAVƏ RAZILAŞMA
[[NÖMRƏ]]
{ŞİRKƏT} (VÖEN {VÖEN}), {RƏHBƏR_VƏZİFƏ_K} {RƏHBƏR} vasitəsilə, və {İŞÇİ} (FİN {FİN}) {MÜQAVİLƏ_TARİXİ} tarixli {MÜQAVİLƏ_NÖ} nömrəli əmək müqaviləsinə aşağıdakı dəyişikliyi etmək barədə razılığa gəldilər:
1. {DƏYİŞİKLİK}
2. Bu razılaşma {TARİXDƏN} tarixdən qüvvəyə minir və əmək müqaviləsinin ayrılmaz hissəsidir.
3. Müqavilənin digər şərtləri dəyişmir. Razılaşma iki nüsxədə tərtib edilir.
[[İMZA_İKİ]]`},{id:`elave-maddi`,cat:`muqavile`,name:`Tam fərdi maddi məsuliyyət haqqında müqavilə`,desc:`Maddi sərvətlərlə işləyənlər`,numbered:!1,legacy:!0,params:[I.area(`İŞLƏR`,`Həvalə edilən işlər`,e=>`${e.position} vəzifəsinin əmək funksiyaları üzrə maddi sərvətlərin qəbulu, saxlanması, istifadəsi və təhvil verilməsi`)],text:`[[BAŞLIQ]]
# TAM FƏRDİ MADDİ MƏSULİYYƏT HAQQINDA MÜQAVİLƏ
[[NÖMRƏ]]
{ŞİRKƏT} (VÖEN {VÖEN}), {RƏHBƏR_VƏZİFƏ_K} {RƏHBƏR} vasitəsilə (bundan sonra — "İşəgötürən"), bir tərəfdən, və {İŞÇİ} (FİN {FİN}), {VƏZİFƏ} (bundan sonra — "İşçi"), digər tərəfdən, {MÜQAVİLƏ_TARİXİ} tarixli {MÜQAVİLƏ_NÖ} nömrəli əmək müqaviləsinə əlavə olaraq aşağıdakılar barədə razılığa gəldilər:
1. İşçi ona etibar edilmiş İşəgötürənin əmlakının, pul vəsaitlərinin, sənədlərinin və digər maddi sərvətlərinin qorunub saxlanmasına görə Azərbaycan Respublikası Əmək Məcəlləsinə uyğun olaraq tam fərdi maddi məsuliyyət daşıyır.
2. İşçiyə həvalə edilən işlər: {İŞLƏR}. Təhvil verilən sərvətlərin siyahısı təhvil-təslim aktında göstərilir.
3. İşçi öhdəsinə götürür: etibar edilmiş sərvətlərə qayğı ilə yanaşmaq və zərərin qarşısını almaq üçün tədbirlər görmək; sərvətlərin təhlükəsizliyinə təhlükə yaradan hallar barədə İşəgötürənə dərhal məlumat vermək; sərvətlərin hərəkəti barədə uçotu aparmaq və hesabatları vaxtında təqdim etmək; inventarizasiyada iştirak etmək.
4. İşəgötürən öhdəsinə götürür: sərvətlərin qorunması üçün zəruri şəraiti yaratmaq; İşçini maddi məsuliyyət haqqında qanunvericiliklə tanış etmək; müəyyən edilmiş qaydada inventarizasiya aparmaq.
5. Zərərin məbləği və ödənilmə qaydası Əmək Məcəlləsində nəzərdə tutulmuş qaydada müəyyən edilir. Zərər İşçinin təqsiri olmadan yaranıbsa, İşçi maddi məsuliyyətdən azad edilir.
6. Müqavilə imzalandığı gündən qüvvəyə minir və İşçinin etibar edilmiş sərvətlərlə işlədiyi bütün müddət ərzində qüvvədədir. Müqavilə iki nüsxədə tərtib edilir.
[[İMZA_İKİ]]`},{id:`elave-konfidensial`,cat:`muqavile`,name:`Konfidensiallıq haqqında razılaşma`,desc:`Kommersiya sirri və şəxsi məlumat`,numbered:!1,legacy:!0,params:[I.text(`İL_SAYI`,`Xitamdan sonra qüvvədə (il)`,`3 (üç)`)],text:`[[BAŞLIQ]]
# KONFİDENSİALLIQ HAQQINDA RAZILAŞMA
[[NÖMRƏ]]
{ŞİRKƏT} (VÖEN {VÖEN}), {RƏHBƏR_VƏZİFƏ_K} {RƏHBƏR} vasitəsilə (bundan sonra — "İşəgötürən"), bir tərəfdən, və {İŞÇİ} (FİN {FİN}), {VƏZİFƏ} (bundan sonra — "İşçi"), digər tərəfdən, {MÜQAVİLƏ_TARİXİ} tarixli {MÜQAVİLƏ_NÖ} nömrəli əmək müqaviləsinə əlavə olaraq aşağıdakılar barədə razılığa gəldilər:
1. Konfidensial məlumat — İşçiyə əmək funksiyasının icrası ilə əlaqədar məlum olan, İşəgötürənin və onun müştərilərinin maliyyə, vergi, mühasibat, kadr, kommersiya və texniki məlumatları, şəxsi məlumatlar, müqavilələr, qiymətlər, müştəri siyahıları və digər açıq olmayan məlumatlardır.
2. İşçi konfidensial məlumatı üçüncü şəxslərə açıqlamamağı, ondan yalnız əmək funksiyasının icrası üçün istifadə etməyi, məlumat daşıyıcılarını (sənəd, fayl, hesab, parol) qorumağı öhdəsinə götürür.
3. Qanunla müəyyən edilmiş hallarda səlahiyyətli dövlət orqanlarına məlumatın təqdim edilməsi bu razılaşmanın pozulması sayılmır.
4. Öhdəlik əmək müqaviləsinin qüvvədə olduğu müddətdə və ona xitam verildikdən sonra {İL_SAYI} il ərzində qüvvədədir. Əmək münasibətləri bitdikdə İşçi konfidensial məlumat daşıyıcılarını İşəgötürənə qaytarır.
5. Razılaşmanı pozan İşçi Azərbaycan Respublikasının qanunvericiliyinə uyğun olaraq məsuliyyət daşıyır və vurduğu zərəri ödəyir.
6. Razılaşma əmək müqaviləsinin ayrılmaz hissəsidir, iki nüsxədə tərtib edilir.
[[İMZA_İKİ]]`},{id:`elave-iltizam`,cat:`muqavile`,name:`İltizam (kommersiya sirrinin qorunması)`,desc:`İşçinin öhdəliyi`,numbered:!1,legacy:!0,params:[],text:`[[BAŞLIQ]]
# İLTİZAM
- {ŞƏHƏR}, {TARİX_SÖZ}

Mən, {İŞÇİ} (FİN {FİN}), {ŞİRKƏT_YERLİK} {VƏZİFƏ} vəzifəsində işlədiyim müddətdə və əmək münasibətlərim bitdikdən sonra aşağıdakıları öhdəmə götürürəm:
1. İşəgötürənin və onun müştərilərinin kommersiya sirrini və konfidensial məlumatlarını yaymamaq, şəxsi məqsədlər üçün istifadə etməmək.
2. İşlə əlaqədar mənə verilən sənədləri, faylları, elektron hesabları və parolları qorumaq, üçüncü şəxslərə verməmək.
3. Əmək münasibətləri bitdikdə bütün sənədləri və məlumat daşıyıcılarını İşəgötürənə qaytarmaq.
4. Bu iltizamı pozduğum halda qanunvericiliyə uyğun məsuliyyət daşıdığım mənə izah edilmişdir.
[[İMZA_İŞÇİ]]`},{id:`muq-vezife-telimati`,cat:`muqavile`,name:`Vəzifə təlimatı`,desc:`Əmək funksiyası, hüquq və vəzifələr`,numbered:!1,params:[I.area(`FUNKSİYA`,`Əsas vəzifələr (hər biri yeni sətirdə deyil, ; ilə)`,e=>`${e.position} vəzifəsinə aid işlərin yerinə yetirilməsi; hesabatların vaxtında hazırlanması; rəhbərliyin tapşırıqlarının icrası`),I.text(`TABE`,`Kimə tabedir`,e=>`direktora`)],text:`[[BAŞLIQ]]
> TƏSDİQ EDİRƏM
> {RƏHBƏR_VƏZİFƏ} ______________ {RƏHBƏR_QISA}
> {TARİX}

# VƏZİFƏ TƏLİMATI
## {VƏZİFƏ}
! 1. Ümumi müddəalar
1.1. {VƏZİFƏ} {TABE} tabedir və vəzifəyə {RƏHBƏR_VƏZİFƏ_YİYƏLİK} əmri ilə təyin və azad edilir.
! 2. Vəzifələr
2.1. {FUNKSİYA}.
! 3. Hüquqlar
3.1. İşin yerinə yetirilməsi üçün zəruri məlumat və sənədləri almaq, işin təkmilləşdirilməsi barədə təkliflər vermək.
! 4. Məsuliyyət
4.1. Vəzifələrin lazımınca yerinə yetirilməməsinə görə Azərbaycan Respublikasının qanunvericiliyinə uyğun məsuliyyət daşıyır.

- Təlimatla tanış oldum: ______________ {İŞÇİ_QISA}    «___» ____________ 20___-ci il`},{id:`arayis-is`,cat:`arayis`,name:`İş yerindən arayış`,desc:`Azərbaycan dilində`,numbered:!0,fmt:`{SIRA}`,legacy:!0,params:[I.text(`YER`,`Təqdim ediləcək yer`,`tələb olunan yerə`,`məs. "bank"a, "səfirliy"ə`,!0),I.sel(`MAAŞLA`,`Əməkhaqqı göstərilsin`,[{value:`1`,label:`Bəli`,text:`yes`},{value:`0`,label:`Xeyr`,text:``}])],text:`[[BAŞLIQ]]
# ARAYIŞ
[[NÖMRƏ]]
Bu arayış {İŞÇİ} (FİN: {FİN}) barəsində ona görə verilir ki, o, həqiqətən {İŞƏ_QƏBUL} tarixindən {ŞİRKƏT_YERLİK} {VƏZİFƏ} vəzifəsində işləyir.
{MAAŞ_CÜMLƏ}
Arayış {YER} təqdim edilmək üçün verilir.
[[İMZA]]`},{id:`arayis-is-en`,cat:`arayis`,name:`Employment certificate (EN)`,desc:`İngilis dilində — səfirlik, xarici bank`,numbered:!0,fmt:`{SIRA}`,lang:`en`,legacy:!0,params:[I.text(`YER`,`Submitted to`,``,`məs. the Embassy of Germany`,!0),I.sel(`MAAŞLA`,`Əməkhaqqı göstərilsin`,[{value:`1`,label:`Bəli`,text:`yes`},{value:`0`,label:`Xeyr`,text:``}])],text:`[[BAŞLIQ]]
# EMPLOYMENT CERTIFICATE
[[NÖMRƏ]]
This is to certify that {EN_MR} {İŞÇİ} (Personal ID: {FİN}) has been employed at {ŞİRKƏT} since {İŞƏ_QƏBUL_EN} and currently holds the position of {VƏZİFƏ}.
{MAAŞ_EN}
This certificate is issued upon {EN_HIS_L} request{YER_EN}.
[[İMZA]]`},{id:`arayis-maas`,cat:`arayis`,name:`Əməkhaqqı arayışı`,desc:`Bank, kredit, viza üçün`,numbered:!0,fmt:`{SIRA}`,params:[I.text(`AY_SAYI`,`Dövr`,`son 6 (altı) ay`,void 0,!0),I.money(`ORTA`,`Aylıq hesablanmış əməkhaqqı`,e=>String(e.salary)),I.text(`YER`,`Təqdim ediləcək yer`,`tələb olunan yerə`,void 0,!0)],text:`[[BAŞLIQ]]
# ARAYIŞ
[[NÖMRƏ]]
Bu arayış {İŞÇİ} (FİN: {FİN}) barəsində ona görə verilir ki, o, {İŞƏ_QƏBUL} tarixindən {ŞİRKƏT_YERLİK} {VƏZİFƏ} vəzifəsində işləyir.
{AY_SAYI} ərzində onun aylıq hesablanmış əməkhaqqı {ORTA} ({ORTA_SÖZLƏ}) təşkil etmişdir. Əməkhaqqından qanunvericiliyə uyğun vergi və sosial ayırmalar tutulur.
Arayış {YER} təqdim edilmək üçün verilir.
[[İMZA]]`},{id:`arayis-staj`,cat:`arayis`,name:`Staj arayışı`,desc:`Bu işəgötürəndə iş stajı`,numbered:!0,fmt:`{SIRA}`,params:[I.text(`YER`,`Təqdim ediləcək yer`,`tələb olunan yerə`,void 0,!0)],text:`[[BAŞLIQ]]
# ARAYIŞ
[[NÖMRƏ]]
Bu arayış {İŞÇİ} (FİN: {FİN}) barəsində ona görə verilir ki, o, {İŞƏ_QƏBUL} tarixindən bu günədək {ŞİRKƏT_YERLİK} {VƏZİFƏ} vəzifəsində işləyir. Bu işəgötürəndə iş stajı {STAJ} təşkil edir.
Arayış e-Sosial elektron informasiya sistemindəki məlumat əsasında {YER} təqdim edilmək üçün verilir.
[[İMZA]]`},{id:`arayis-mezuniyyet`,cat:`arayis`,name:`Məzuniyyət qalığı arayışı`,desc:`İstifadə olunmamış günlər`,numbered:!0,fmt:`{SIRA}`,params:[I.days(`GÜN`,`İstifadə olunmamış gün`,e=>String(Math.max(0,Math.round(e.balance??0))))],text:`[[BAŞLIQ]]
# ARAYIŞ
[[NÖMRƏ]]
Bu arayış {VƏZİFƏ} {İŞÇİ} (FİN: {FİN}) barəsində ona görə verilir ki, {TARİX} tarixə onun istifadə olunmamış əmək məzuniyyəti {GÜN_SÖZLƏ} təqvim günü təşkil edir (illik norma {NORMA} gün).
Hesablama e-Sosial sistemindəki imzalanmış məzuniyyət əmrləri əsasında aparılıb.
[[İMZA_KADR]]`},{id:`akt-izahat-teleb`,cat:`akt`,name:`İzahat tələbi`,desc:`İntizam tənbehindən əvvəl`,numbered:!0,fmt:`{SIRA}-İ`,params:[I.area(`HAL`,`Hadisə (nə, nə vaxt)`,e=>`${T(e.today)} tarixdə iş yerində üzrlü səbəb olmadan olmamağınız`),I.days(`MÜDDƏT`,`İzahat üçün müddət (iş günü)`,`2`)],text:`[[BAŞLIQ]]
> {VƏZİFƏ} {İŞÇİ_YÖNLÜK}

# İZAHAT TƏLƏBİ
[[NÖMRƏ]]
{HAL} ilə əlaqədar {MÜDDƏT_SÖZLƏ} iş günü ərzində yazılı izahat təqdim etməyiniz xahiş olunur.
İzahat verilmədikdə bu barədə akt tərtib ediləcək.
[[İMZA]]

- Tələbi aldım: ______________ {İŞÇİ_QISA}    «___» ____________ 20___-ci il`},{id:`akt-izahat`,cat:`akt`,name:`İşçinin izahatı`,desc:`İzahat tələbinə cavab`,numbered:!1,params:[I.area(`MƏTN`,`İzahat`,``)],text:`${W.replace(`# ƏRİZƏ`,`# İZAHAT`)}{MƏTN}
${G}`},{id:`akt-gelmeme`,cat:`akt`,name:`İşə gəlməmə aktı`,desc:`Üç şəxsin imzası ilə`,numbered:!0,fmt:`{SIRA}-A`,params:[I.date(`GÜN_TARİX`,`Tarix`,L),I.text(`VAXT`,`Vaxt aralığı`,`09:00-dan 18:00-dək`),I.area(`KOMİSSİYA`,`Aktı tərtib edənlər (vəzifə, ad)`,`1. ____________________
2. ____________________
3. ____________________`)],text:`[[BAŞLIQ]]
# İŞƏ GƏLMƏMƏ HAQQINDA AKT
[[NÖMRƏ]]
Biz, aşağıda imza edənlər, bu aktı ona görə tərtib edirik ki, {VƏZİFƏ} {İŞÇİ} {GÜN_TARİX} tarixdə {VAXT} iş yerində olmamışdır. Yoxluğun səbəbi barədə məlumat verilməmişdir.
- Aktı tərtib edənlər:
{KOMİSSİYA}
- İmzalar: ______________   ______________   ______________`},{id:`akt-xidmeti-meruze`,cat:`akt`,name:`Xidməti məruzə`,desc:`Rəhbərə — ezamiyyə, mükafat və s.`,numbered:!1,params:[I.area(`MƏTN`,`Məruzənin mətni`,e=>`${e.position} vəzifəsində çalışan işçinin xidməti tapşırığı yerinə yetirmək üçün ezamiyyətə göndərilməsini xahiş edirəm.`)],text:`> {ŞİRKƏT_YİYƏLİK}
> {RƏHBƏR_VƏZİFƏSİ} {RƏHBƏR_YÖNLÜK}

# XİDMƏTİ MƏRUZƏ
- {TARİX}
{MƏTN}
- İşçi: {İŞÇİ}, {VƏZİFƏ}
[[İMZA_KADR]]`},{id:`akt-tehvil`,cat:`akt`,name:`Təhvil-təslim aktı`,desc:`İşlərin və sərvətlərin təhvili`,numbered:!0,fmt:`{SIRA}-A`,params:[I.text(`QƏBUL_EDƏN`,`Qəbul edən (vəzifə, ad)`,``),I.area(`SİYAHI`,`Təhvil verilənlər`,`1. ____________________ — ___ ədəd
2. ____________________ — ___ ədəd`)],text:`[[BAŞLIQ]]
# TƏHVİL-TƏSLİM AKTI
[[NÖMRƏ]]
{VƏZİFƏ} {İŞÇİ} (təhvil verən) aşağıdakı işləri, sənədləri və maddi sərvətləri {QƏBUL_EDƏN} (qəbul edən) şəxsə təhvil verdi:
{SİYAHI}
Tərəflərin bir-birinə iddiası yoxdur.
- Təhvil verdi: ______________ {İŞÇİ_QISA}
- Qəbul etdi: ______________
[[İMZA]]`},{id:`akt-ezamiyye-vesiqe`,cat:`akt`,name:`Ezamiyyə vəsiqəsi (daxili)`,desc:`Gəliş-gediş qeydləri ilə`,numbered:!0,fmt:`{SIRA}-V`,params:[I.text(`YER`,`Ezamiyyə yeri`,``),I.date(`BAŞLAMA`,`Başlama`,V),I.days(`GÜN`,`Müddət (gün)`,`3`),I.text(`ƏMR`,`Əmr (№, tarix)`,``)],text:`[[BAŞLIQ]]
# EZAMİYYƏ VƏSİQƏSİ
[[NÖMRƏ]]
- İşçi: {İŞÇİ}, {VƏZİFƏ}
- Ezamiyyə yeri: {YER}
- Müddət: {BAŞLAMA} – {BİTMƏ} ({GÜN_SÖZLƏ} gün)
- Əsas: {ƏMR} nömrəli əmr
[[İMZA]]

## Gəliş və gediş haqqında qeydlər
- Gəldi: «___» ____________ 20___    İmza, möhür: ______________
- Getdi: «___» ____________ 20___    İmza, möhür: ______________`},{id:`akt-sinaq`,cat:`akt`,name:`Sınaq müddətinin nəticəsi`,desc:`Sınaq bitəndə qərar`,numbered:!0,fmt:`{SIRA}-S`,params:[I.sel(`NƏTİCƏ`,`Nəticə`,[{value:`ok`,label:`Sınaqdan keçib`,text:`sınaq müddətini müvəffəqiyyətlə başa vurmuşdur və işini davam etdirir`},{value:`no`,label:`Sınaqdan keçməyib`,text:`sınaq müddətində qoyulmuş tələbləri yerinə yetirməmişdir`}]),I.area(`QEYD`,`Qiymətləndirmə`,`Əmək funksiyasını lazımi səviyyədə yerinə yetirir.`)],text:`[[BAŞLIQ]]
# SINAQ MÜDDƏTİNİN NƏTİCƏSİ HAQQINDA
[[NÖMRƏ]]
{İŞƏ_QƏBUL} tarixdən {VƏZİFƏ} vəzifəsində sınaq müddəti ilə işə qəbul edilmiş {İŞÇİ} {NƏTİCƏ}.
{QEYD}
[[İMZA]]
[[TANIŞ]]`}],J=e=>q.find(t=>t.id===e);function Y(e){if(e.openYear)return`${X(e.openYear.from)} – ${X(e.openYear.to)}`;if(!e.start)return`________`;let t=e.today,n=t.getFullYear(),i=new Date(n,e.start.getMonth(),e.start.getDate());i>t&&(i=new Date(--n,e.start.getMonth(),e.start.getDate()));let a=r(new Date(n+1,e.start.getMonth(),e.start.getDate()),-1);return`${X(i)} – ${X(a)}`}var X=e=>`${String(e.getDate()).padStart(2,`0`)}.${String(e.getMonth()+1).padStart(2,`0`)}.${e.getFullYear()}`,Z=e=>{let t=/^(\d{4})-(\d{2})-(\d{2})$/.exec(e);return t?new Date(+t[1],t[2]-1,+t[3]):null},Q=e=>Number(String(e).replace(/\s/g,``).replace(`,`,`.`))||0;function $(e,n){let i=new Date(e),a=0;for(let e=0;e<400&&a<n;e++)t(i)||a++,a<n&&(i=r(i,1));return i}function oe(e){let n=r(e,1);for(let e=0;e<20&&(n.getDay()===0||n.getDay()===6||t(n));e++)n=r(n,1);return n}function se(e,t){let n={};for(let r of e.params)n[r.id]=typeof r.def==`function`?r.def(t):r.def??``;return n}function ce(e,t,n){let i={};for(let n of e.params){let e=t[n.id]??``;if(n.type===`date`){let t=Z(e);i[n.id]=t?T(t):`________`,i[`${n.id}_EN`]=t?t.toLocaleDateString(`en-GB`,{day:`numeric`,month:`long`,year:`numeric`}):`________`}else if(n.type===`days`){let t=Math.round(Q(e));i[n.id]=String(t),i[`${n.id}_SÖZLƏ`]=k(t)}else if(n.type===`money`){let t=Q(e);i[n.id]=O(t),i[`${n.id}_SÖZLƏ`]=a(t)}else if(n.type===`select`){let t=n.options?.find(t=>t.value===e)??n.options?.[0];i[n.id]=t?.text??t?.label??e}else i[n.id]=e.trim()}let o=Z(t.BAŞLAMA??``),s=Math.round(Q(t.GÜN??``));if(o&&s>0){let t=e.id.includes(`mezuniyyet`)?$(o,s):r(o,s-1);i.BİTMƏ=T(t),i.İŞƏ_ÇIXMA=T(oe(t))}if(`MAAŞLA`in t){let e=t.MAAŞLA===`1`;i.MAAŞ_CÜMLƏ=e?`Aylıq əməkhaqqı ${n.MAAŞ} (${n.MAAŞ_SÖZLƏ}) təşkil edir.`:``,i.MAAŞ_EN=e?`${n.EN_HIS} monthly salary is ${n.MAAŞ} AZN.`:``}return e.lang===`en`&&(i.YER_EN=t.YER?.trim()?` for submission to ${t.YER.trim()}`:``),i}export{J as a,ce as c,M as d,te as f,R as i,A as l,q as n,$ as o,re as p,z as r,se as s,ie as t,w as u};