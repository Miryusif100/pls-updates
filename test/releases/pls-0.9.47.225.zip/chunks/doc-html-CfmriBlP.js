import{n as e,r as t}from"./doc-designs-BF1SM5mV.js";var n=1123,r=`
.dpg { position: relative; box-sizing: border-box; width: 794px; min-height: ${n}px; padding: 56px 56px 64px; background: #fff; color: #111; font: 400 12.5px/1.45 'IBM Plex Sans', Arial, sans-serif; }
.dpg * { box-sizing: border-box; }
.dpg p { margin: 0 0 6px; }
.dpg h1 { margin: 0 0 3px; font-size: 17px; font-weight: 700; text-align: center; letter-spacing: .01em; }
.dpg .dp-sub { text-align: center; margin: 0 0 16px; }
.dpg .dp-intro { margin: 0 0 12px; text-align: justify; }
.dpg table.dp-items { width: 100%; border-collapse: collapse; margin: 4px 0 8px; }
.dpg table.dp-items th, .dpg table.dp-items td { border: 1px solid #222; padding: 4px 6px; vertical-align: top; }
.dpg table.dp-items th { background: #eef1f5; font-weight: 700; text-align: center; font-size: 11.5px; }
.dpg .al { text-align: left; } .dpg .ar { text-align: right; white-space: nowrap; font-variant-numeric: tabular-nums; } .dpg .ac { text-align: center; }
.dpg .dp-tot { width: 100%; border-collapse: collapse; margin: 2px 0 8px; }
.dpg .dp-tot td { padding: 2px 6px; text-align: right; } .dpg .dp-tot td:first-child { width: 75%; } .dpg .dp-tot tr.b td { font-weight: 700; }
.dpg .dp-sign { width: 100%; border-collapse: collapse; margin-top: 22px; }
.dpg .dp-sign td { width: 50%; vertical-align: top; padding: 0 8px 0 0; }
.dpg .dp-sign .dp-st { font-weight: 700; } .dpg .dp-sign .dp-org { margin-bottom: 8px; } .dpg .dp-sign .dp-pp { margin: 0 0 3px; }
.dpg .dp-sign .dp-line { margin-top: 4px; } .dpg .dp-sign .dp-my { margin-top: 8px; }
.dpg .dp-foot { margin-top: 26px; font-size: 10px; font-style: italic; color: #444; }
`,i=`U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+20AC, U+2122, U+2212`,a=`U+0100-02AF, U+0304, U+0308, U+0329, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20C0, U+2113, U+2C60-2C7F, U+A720-A7FF`,o=[400,500,600,700].map(e=>`@font-face{font-family:'DocPlex';font-weight:${e};font-display:block;src:url('/fonts/plex-latin-${e}.woff2') format('woff2');unicode-range:${i}}@font-face{font-family:'DocPlex';font-weight:${e};font-display:block;src:url('/fonts/plex-latin-ext-${e}.woff2') format('woff2');unicode-range:${a}}`).join(``)+`@font-face{font-family:'DocMont';font-weight:800;font-display:block;src:url('/fonts/mont-latin-800.woff2') format('woff2');unicode-range:${i}}@font-face{font-family:'DocMont';font-weight:800;font-display:block;src:url('/fonts/mont-ext-800.woff2') format('woff2');unicode-range:${a}}`,s=`
.dpg.dz { position: relative; width: 794px; height: ${n}px; min-height: 0; padding: 0; overflow: hidden; background: #fff; color: #16181d; box-sizing: border-box; font-size: 10.5px; line-height: 1.45; display: flex; flex-direction: column; text-align: left; }
.dpg.dz * { box-sizing: border-box; }
.dpg.dz > *, .dpg.dz > * > * { flex-shrink: 0; }
/* 29.10.2026 (sahib, 0.9.51): üfüqi sətirlərdə «min-width:0» olan blok (şirkətin adı) daralır və sətrə bölünür — uzun ad sağdakı
   başlığı / nömrəni səhifədən çıxarmırdı (əvvəl yuxarıdakı qayda ilə daralmırdı) */
.dpg.dz [style*="min-width:0"] { flex-shrink: 1; overflow-wrap: anywhere; }
.dpg.dz table { font-size: inherit; color: inherit; border-collapse: collapse; width: auto; }
.dpg.dz td { padding: 1px 12px 1px 0; vertical-align: top; }
.dpg.dz p { margin: 0; }
.dpg.dz .n { text-align: right; font-variant-numeric: tabular-nums; white-space: nowrap; }
.dpg.dz .end { margin-top: auto; }
.dpg.dz .lbl { font-size: 8.5px; font-weight: 700; letter-spacing: .08em; text-transform: uppercase; }
.dpg.dz .ct { width: 100% !important; border-collapse: collapse; }
.dpg.dz .ct > * > tr > th, .dpg.dz .ct > * > tr > td { border: 1px solid #2b2b2b; padding: 5px 7px; vertical-align: middle; }
.dpg.dz .ct td table td { border: 0; }
.dpg.dz .ct > * > tr > th { font-weight: 700; font-size: 9.5px; text-align: center; line-height: 1.25; }
.dpg.dz .sec { display: inline-block; font-size: 10px; font-weight: 700; letter-spacing: .14em; text-transform: uppercase; }
.dpg.dz:not(.flow) .end { margin-bottom: 30px; }
.dpg.dz.flow .end { margin-top: 34px !important; }
.dpg.dz.flow .end ~ *:not(.end) { margin-top: auto !important; }
.dpg.dz.mid .end { display: none; }
.dpg.dz.mid .end ~ *:not(.end) { margin-top: auto !important; }
.dz-stack { display: flex; flex-direction: column; gap: 16px; align-items: flex-start; }
@media print { .dz-stack { gap: 0; } .dpg.dz { break-after: page; page-break-after: always; } .dpg.dz:last-child { break-after: auto; page-break-after: auto; } }
`,c=o+r+s,l=e,u=e=>e.en?.title?e.en.title.replace(/\s*№\s*\S+$/,``):``,d=`:host { display: block; } .dsr { all: initial; display: block; color: #111; font-family: 'DocPlex', 'IBM Plex Sans', Arial, sans-serif; }`+r+s;function f(){if(typeof document>`u`||!document.head||document.getElementById(`pls-doc-fonts`))return;let e=document.createElement(`style`);e.id=`pls-doc-fonts`,e.textContent=o,document.head.appendChild(e)}function p(e,t,n=``){f();let r=e.shadowRoot??e.attachShadow({mode:`open`});return r.innerHTML=`<style>${d}${n}</style><div class="dsr">${t}</div>`,r.querySelector(`.dsr`)}var m=null;function h(){if(typeof document>`u`||!document.body)return null;m&&m.isConnected||(m=document.createElement(`div`),m.setAttribute(`aria-hidden`,`true`),m.setAttribute(`data-doc-meas`,``),m.style.cssText=`position:fixed;left:-20000px;top:0;width:794px;height:${n}px;overflow:hidden;pointer-events:none;z-index:-1;`,document.body.appendChild(m));let e=m.shadowRoot?.querySelector(`.dsr`)??p(m,``);return t=>{e.innerHTML=t;let n=e.firstElementChild,r=!n||n.scrollHeight<=1124;return e.innerHTML=``,r}}async function g(){let e=typeof document<`u`?document.fonts:null;if(e){f();try{await Promise.all([`400 10px DocPlex`,`600 10px DocPlex`,`700 10px DocPlex`,`800 10px DocMont`,`400 10px DocPlex`].map(t=>e.load(t,`AaƏəİıĞğŞşÇçÖöÜü`)))}catch{}try{await e.ready}catch{}}}function _(e,n){let r=n===void 0?h():n,i=e.rows,a=n=>t(e,{rows:i,last:!0,dense:0,page:1,pages:1,cont:!1,...n});if(!r)return[a({})];for(let e=0;e<4;e++){let t=a({dense:e});if(r(t))return[t]}let o=[],s=0;for(;s<i.length;){let n=o.length===0,a=i.length-s;if(!n&&r(t(e,{rows:i.slice(s),last:!0,dense:1,page:o.length+1,pages:9,cont:!0}))){o.push({from:s,to:i.length});break}let c=a-+!!n,l=n?Math.min(2,a):1;for(;c>l&&!r(t(e,{rows:i.slice(s,s+c),last:!1,dense:1,page:o.length+1,pages:9,cont:!n}));c--);if(c=Math.max(1,Math.min(c,a)),!n&&c>=a&&(c=a-1||1),o.push({from:s,to:s+c}),s+=c,s>=i.length){let e=o[o.length-1];if(e.to-e.from>1)e.to--,s=e.to;else break}if(o.length>200)break}let c=o.length;return o.map((n,r)=>t(e,{rows:i.slice(n.from,n.to),last:r===c-1,dense:1,page:r+1,pages:c,cont:r>0}))}var v=`@page{size:A4;margin:0}html,body{margin:0;padding:0;background:#fff}*{-webkit-print-color-adjust:exact;print-color-adjust:exact}@media print{.dpg.dz{height:297mm}}`,y=e=>e.replace(/[&<>"]/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`})[e]);function b(e,t=`Sənəd`){return`<!doctype html><html lang="az"><head><meta charset="utf-8"><title>${y(t)}</title><style>${o}${d}${v}</style></head><body><div class="dsr">${e}</div></body></html>`}var x=[`400 10px DocPlex`,`500 10px DocPlex`,`600 10px DocPlex`,`700 10px DocPlex`,`800 10px DocMont`];async function S(e,t=6e3){let n=e.fonts,r=n?Promise.all(x.map(e=>n.load(e,`AaƏəİıĞğŞşÇçÖöÜü`).catch(()=>null))).then(()=>n.ready).catch(()=>null):null,i=[...e.images].map(e=>e.complete?null:new Promise(t=>{e.addEventListener(`load`,t,{once:!0}),e.addEventListener(`error`,t,{once:!0})}));await Promise.race([Promise.all([r,...i]),new Promise(e=>setTimeout(e,t))])}async function C(e,t){let n=document.createElement(`iframe`);n.setAttribute(`aria-hidden`,`true`),n.setAttribute(`data-doc-print`,``),n.style.cssText=`position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden`,document.body.append(n);let r=n.contentDocument;r.open(),r.write(b(e,t)),r.close();try{await S(r),n.contentWindow?.focus(),n.contentWindow?.print()}finally{window.setTimeout(()=>n.remove(),1500)}}export{u as a,C as c,p as i,c as n,_ as o,g as r,l as s,n as t};