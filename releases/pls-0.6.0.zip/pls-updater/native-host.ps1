﻿# Chrome "native messaging" körpüsü: genişlənmədəki "İndi yenilə" düyməsi bu skripti çağırır.
# Protokol: stdin — 4 bayt uzunluq + JSON, stdout — eyni formatda cavab. Stdout-a başqa heç nə yazılmamalıdır.
$ErrorActionPreference = 'Stop'

function Read-Message {
  $in = [Console]::OpenStandardInput()
  $lenBuf = New-Object byte[] 4
  $n = 0
  while ($n -lt 4) { $r = $in.Read($lenBuf, $n, 4 - $n); if ($r -le 0) { return $null }; $n += $r }
  $len = [BitConverter]::ToInt32($lenBuf, 0)
  $buf = New-Object byte[] $len
  $n = 0
  while ($n -lt $len) { $r = $in.Read($buf, $n, $len - $n); if ($r -le 0) { break }; $n += $r }
  return ([Text.Encoding]::UTF8.GetString($buf, 0, $n) | ConvertFrom-Json)
}

function Write-Message($obj) {
  $bytes = [Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress -Depth 5))
  $out = [Console]::OpenStandardOutput()
  $out.Write([BitConverter]::GetBytes([int]$bytes.Length), 0, 4)
  $out.Write($bytes, 0, $bytes.Length)
  $out.Flush()
}

. (Join-Path $PSScriptRoot 'pls-updater.ps1') -Quiet

$msg = Read-Message
if ($msg.action -eq 'update') { Write-PlsLog 'Genişlənmədən yeniləmə istəyi gəldi.' }
try {
  switch ($msg.action) {
    'update' { $res = Invoke-PlsUpdate -ForceUpdate:([bool]$msg.force) }
    'device' { $res = Get-PlsDevice }
    'status' { $res = [pscustomobject]@{ success = $true; installed = $true; version = (Get-PlsLocalVersion); root = $Script:Root } }
    default { $res = [pscustomobject]@{ success = $false; message = "Naməlum əmr: $($msg.action)" } }
  }
} catch {
  Write-PlsLog ('XƏTA (native): ' + $_.Exception.Message)
  $res = [pscustomobject]@{ success = $false; updated = $false; message = $_.Exception.Message }
}
Write-Message $res
