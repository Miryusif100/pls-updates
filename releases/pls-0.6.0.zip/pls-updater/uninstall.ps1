﻿# PLS-i kompüterdən silir: yeniləyici, planlaşdırılmış tapşırıq, Startup, brauzer körpüsü və fayllar.
$ErrorActionPreference = 'SilentlyContinue'
$HostName = 'az.plsconsulting.updater'
$Root = Join-Path $env:LOCALAPPDATA 'PLS'
Unregister-ScheduledTask -TaskName 'PLS Yenileyici' -Confirm:$false
Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath('Startup')) 'PLS Yenileyici.vbs') -Force
Remove-Item -Path "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$HostName" -Recurse -Force
Remove-Item -Path "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\$HostName" -Recurse -Force
Remove-Item -LiteralPath $Root -Recurse -Force
Write-Host 'PLS silindi. Chrome-da chrome://extensions səhifəsindən PLS kartını da "Remove" edin.'
