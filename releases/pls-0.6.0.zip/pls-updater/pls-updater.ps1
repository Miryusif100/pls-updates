﻿# PLS yeniləyici — Windows üçün.
# İşə düşəndə GitHub-dakı (pls-updates) son versiyanı yoxlayır, faylın PLS açarı ilə
# imzalandığını təsdiqləyir və genişlənmə qovluğunu yeniləyir. İmza düzgün deyilsə heç nə yazmır.
#
# İstifadə:  powershell -NoProfile -ExecutionPolicy Bypass -File pls-updater.ps1 [-Force] [-Quiet]

param([switch]$Force, [switch]$Quiet, [switch]$Json)

$ErrorActionPreference = 'Stop'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

$Script:Root = if ($env:PLS_ROOT) { $env:PLS_ROOT } else { Join-Path $env:LOCALAPPDATA 'PLS' }
$Script:ExtDir = Join-Path $Script:Root 'extension'
$Script:UpdDir = Join-Path $Script:Root 'updater'
$Script:LogFile = Join-Path $Script:Root 'updater.log'
$Script:FeedBase = if ($env:PLS_FEED_BASE) { $env:PLS_FEED_BASE } else { 'https://raw.githubusercontent.com/Miryusif100/pls-updates/main/' }

# PLS buraxılış açarının AÇIQ hissəsi (gizli hissə yalnız PLS-in kompüterindədir).
$Script:PublicKeyXml = '<RSAKeyValue><Modulus>2qPQNnIy15Pj4ziFkXnD3qEaomX6mIuTAxzw4ktKHS0ykZvyWmUb2DT78QdD9IKhZC4p+pjYc8e1ADAkbQQlBdtIr/0DEwSYRttHiWHdZBq0aaV0Ub5xWProBJ+qu9jQCcg1dd+8JbCK0RjgSRdCXewZtqaMxINzCQ9H4LJTrCi70OjU4P+YhO/UKAtDVEiBW92oboQ3jy+KRcXUvB1qhBszqqPAVxtGybkVSrC4JJcRI5kz5iu0GLM+VQWjxULejwqDXEMHquVhMDvDpBKOyrq+8ajS8LC2NiPj1mXb0ph/S7EawT8umOhNClZ5LvrZNhbPdBhhoEUkv5CGSEWPGmFa+vSrSgCUdmbYzPXGqwk7cB8m5E2704FRfrRWBR4NaVVOTi4551ipuNpfXHU52qlXJMN5dPU/IunA02mZ4270LnBIlat/eihlkyRjaFKxKhqjVlRyz3JLPvOcZwdmFNfmSgoFiQEBsXYMDJYrgdesK2S1f63foqjkkn5mUBg1</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'
if ($env:PLS_PUBLIC_KEY_XML) { $Script:PublicKeyXml = $env:PLS_PUBLIC_KEY_XML }  # yalnız test üçün

function Write-PlsLog([string]$Message) {
  if (-not (Test-Path $Script:Root)) { New-Item -ItemType Directory -Path $Script:Root -Force | Out-Null }
  $line = '[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
  Add-Content -Path $Script:LogFile -Value $line -Encoding UTF8
  if (-not $Quiet -and -not $Json) { Write-Host $line }
}

function Get-PlsLocalVersion {
  $mf = Join-Path $Script:ExtDir 'manifest.json'
  if (-not (Test-Path $mf)) { return '0.0.0' }
  try { return ([IO.File]::ReadAllText($mf) | ConvertFrom-Json).version } catch { return '0.0.0' }
}

# Kompüterin sabit ID-si: Windows-un MachineGuid dəyərinin hash-i (dəyərin özü heç yerə göndərilmir).
function Get-PlsDevice {
  $guid = $env:PLS_TEST_MACHINE_GUID
  if (-not $guid) {
    $base = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, [Microsoft.Win32.RegistryView]::Registry64)
    $guid = $base.OpenSubKey('SOFTWARE\Microsoft\Cryptography').GetValue('MachineGuid')
  }
  if (-not $guid) { throw 'Kompüterin ID-si oxunmadı' }
  $sha = [Security.Cryptography.SHA256]::Create()
  $id = -join ($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes('pls-device-v1:' + $guid)) | ForEach-Object { $_.ToString('x2') })
  $name = if ($env:COMPUTERNAME) { $env:COMPUTERNAME } else { [Environment]::MachineName }
  return [pscustomobject]@{ success = $true; device_id = $id; device_name = $name }
}

function Test-PlsNewer([string]$a, [string]$b) { return ([version]$a) -gt ([version]$b) }

function Test-PlsSignature([byte[]]$Data, [string]$SignatureB64) {
  $rsa = [Security.Cryptography.RSA]::Create()
  $rsa.FromXmlString($Script:PublicKeyXml)
  $sig = [Convert]::FromBase64String($SignatureB64)
  return $rsa.VerifyData($Data, $sig, [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pkcs1)
}

function Get-PlsBytes([string]$Url) {
  $wc = New-Object Net.WebClient
  $wc.Headers.Add('Cache-Control', 'no-cache')
  try { return $wc.DownloadData($Url) } finally { $wc.Dispose() }
}

function Invoke-PlsUpdate([switch]$ForceUpdate) {
  $local = Get-PlsLocalVersion
  $stamp = [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
  $feedText = [Text.Encoding]::UTF8.GetString((Get-PlsBytes ($Script:FeedBase + 'latest.json?t=' + $stamp)))
  $feed = $feedText | ConvertFrom-Json
  if (-not $feed.version -or -not $feed.file -or -not $feed.sha256 -or -not $feed.signature) { throw 'latest.json formatı səhvdir' }

  if (-not $ForceUpdate -and -not (Test-PlsNewer $feed.version $local)) {
    Write-PlsLog "Yeni versiya yoxdur. Quraşdırılıb: $local, son: $($feed.version)"
    return [pscustomobject]@{ success = $true; updated = $false; version = $local; latest = $feed.version; message = 'Son versiya quraşdırılıb' }
  }

  Write-PlsLog "Yeni versiya: $($feed.version) (quraşdırılıb: $local). Yüklənir..."
  $bytes = Get-PlsBytes ($Script:FeedBase + $feed.file + '?t=' + $stamp)

  $sha = [Security.Cryptography.SHA256]::Create()
  $hash = -join ($sha.ComputeHash($bytes) | ForEach-Object { $_.ToString('x2') })
  if ($hash -ne $feed.sha256.ToLower()) { throw "Faylın hash-i uyğun gəlmir ($hash)" }
  if (-not (Test-PlsSignature $bytes $feed.signature)) { throw 'İMZA DÜZGÜN DEYİL — fayl PLS tərəfindən imzalanmayıb, quraşdırılmadı' }
  Write-PlsLog 'İmza təsdiqləndi.'

  $tmp = Join-Path ([IO.Path]::GetTempPath()) ('pls-' + [guid]::NewGuid().ToString('N'))
  New-Item -ItemType Directory -Path $tmp | Out-Null
  try {
    $zipPath = Join-Path $tmp 'pls.zip'
    [IO.File]::WriteAllBytes($zipPath, $bytes)
    $x = Join-Path $tmp 'x'
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::ExtractToDirectory($zipPath, $x)

    $newMf = Join-Path $x 'manifest.json'
    if (-not (Test-Path $newMf)) { throw 'Paketdə manifest.json yoxdur' }
    $newVer = ([IO.File]::ReadAllText($newMf) | ConvertFrom-Json).version
    if ($newVer -ne $feed.version) { throw "Paketin versiyası ($newVer) elanla ($($feed.version)) uyğun deyil" }

    if (-not (Test-Path $Script:ExtDir)) { New-Item -ItemType Directory -Path $Script:ExtDir -Force | Out-Null }
    # Paketdə yeniləyicinin öz yeni faylları varsa (pls-updater\), onları updater qovluğuna köçür.
    $updSrc = Join-Path $x 'pls-updater'
    if (Test-Path $updSrc) {
      if (-not (Test-Path $Script:UpdDir)) { New-Item -ItemType Directory -Path $Script:UpdDir -Force | Out-Null }
      Get-ChildItem -Path $updSrc -File | ForEach-Object {
        try { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $Script:UpdDir $_.Name) -Force } catch { Write-PlsLog "Yeniləyici faylı yenilənmədi: $($_.Name)" }
      }
      Remove-Item -LiteralPath $updSrc -Recurse -Force
      Write-PlsLog 'Yeniləyicinin özü də yeniləndi.'
    }

    $newFiles = Get-ChildItem -Path $x -Recurse -File | ForEach-Object { $_.FullName.Substring($x.Length).TrimStart('\', '/') }

    # 1) manifest-dən başqa bütün fayllar  2) manifest ən sonda — genişlənmə yarımçıq versiyanı götürməsin
    foreach ($rel in $newFiles) {
      if ($rel -eq 'manifest.json') { continue }
      $dst = Join-Path $Script:ExtDir $rel
      $dir = Split-Path $dst -Parent
      if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
      Copy-Item -LiteralPath (Join-Path $x $rel) -Destination $dst -Force
    }
    Copy-Item -LiteralPath $newMf -Destination (Join-Path $Script:ExtDir 'manifest.json') -Force

    # 3) köhnə versiyadan qalan artıq faylları təmizlə
    $keep = @{}; foreach ($f in $newFiles) { $keep[$f.ToLower()] = $true }
    Get-ChildItem -Path $Script:ExtDir -Recurse -File | ForEach-Object {
      $rel = $_.FullName.Substring($Script:ExtDir.Length).TrimStart('\', '/')
      if (-not $keep.ContainsKey($rel.ToLower())) { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue }
    }
  } finally {
    Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
  }

  Write-PlsLog "Yeniləndi: $local -> $($feed.version). Chrome genişlənməni 1 dəqiqə ərzində özü yenidən yükləyəcək."
  return [pscustomobject]@{ success = $true; updated = $true; version = $feed.version; latest = $feed.version; message = "Yeniləndi: $($feed.version)" }
}

# Birbaşa işə salınıbsa (native host-dan "dot-source" edilməyibsə) yeniləməni icra et.
if ($MyInvocation.InvocationName -ne '.') {
  try {
    $r = Invoke-PlsUpdate -ForceUpdate:$Force
  } catch {
    Write-PlsLog ('XƏTA: ' + $_.Exception.Message)
    $r = [pscustomobject]@{ success = $false; updated = $false; version = (Get-PlsLocalVersion); message = $_.Exception.Message }
  }
  if ($Json) { $r | ConvertTo-Json -Compress }
  if (-not $r.success) { exit 1 }
}
