﻿# Chrome "native messaging" körpüsü: genişlənmədəki "İndi yenilə" düyməsi və kompüter ID-si bu skriptdən keçir.
# Protokol: stdin — 4 bayt uzunluq + JSON, stdout — eyni formatda cavab. Stdout-a başqa heç nə yazılmamalıdır.
# Əmrlər (ağ siyahı): update {sha?}, device, status. "force" qəbul olunmur (T-12): köhnə versiyaya qaytarma yalnız əl ilə.
$ErrorActionPreference = 'Stop'

function Read-Message {
  $in = [Console]::OpenStandardInput()
  $lenBuf = New-Object byte[] 4
  $n = 0
  while ($n -lt 4) { $r = $in.Read($lenBuf, $n, 4 - $n); if ($r -le 0) { return $null }; $n += $r }
  $len = [BitConverter]::ToInt32($lenBuf, 0)
  if ($len -le 0 -or $len -gt 65536) { return $null }
  $buf = New-Object byte[] $len
  $n = 0
  while ($n -lt $len) { $r = $in.Read($buf, $n, $len - $n); if ($r -le 0) { break }; $n += $r }
  return ([Text.Encoding]::UTF8.GetString($buf, 0, $n) | ConvertFrom-Json)
}

function Write-Message($obj) {
  $bytes = [Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Compress -Depth 5))
  $out = [Console]::OpenStandardOutput()
  $out.Write([BitConverter]::GetBytes([int]$bytes.Length), 0, 4)
  $out.Write($bytes, 0, $bytes.Length)
  $out.Flush()
}

. (Join-Path $PSScriptRoot 'pls-updater.ps1') -Quiet

$msg = Read-Message
try {
  switch ("$($msg.action)") {
    'update' {
      $sha = "$($msg.sha)"
      if ($sha -and $sha -cnotmatch '^[0-9a-f]{40}$') { throw 'Yanlış commit SHA' }
      Write-PlsLog ('Genişlənmədən yeniləmə istəyi gəldi' + $(if ($sha) { " (commit $($sha.Substring(0, 7)))." } else { '.' }))
      $res = Invoke-PlsUpdate -Sha $sha
      try { Update-PlsTask } catch {}
    }
    'device' { $res = Get-PlsDevice }
    'status' { $res = [pscustomobject]@{ success = $true; installed = $true; version = (Get-PlsLocalVersion); root = $Script:Root; shaFeed = $true } }
    default { $res = [pscustomobject]@{ success = $false; message = "Naməlum əmr: $($msg.action)" } }
  }
} catch {
  Write-PlsLog ('XƏTA (native): ' + $_.Exception.Message)
  $res = [pscustomobject]@{ success = $false; updated = $false; message = $_.Exception.Message }
}
Write-Message $res
