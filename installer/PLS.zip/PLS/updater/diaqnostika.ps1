﻿# PLS diaqnostikası: dəstəyə göndərmək üçün masaüstündə PLS-diaqnostika-<tarix>.zip yaradır.
# İçində: yeniləyicinin jurnalı, versiyalar, faylların hash-i, tapşırıq və brauzer körpüsünün vəziyyəti.
# Tokenlər, şifrələr, sinxron faylları, kompüter və istifadəçi adı DAXİL EDİLMİR (yollarda istifadəçi qovluğu %USERPROFILE% ilə əvəz olunur).
#   -TestMode  yalnız testlər: PLS_ROOT və PLS_TEST_OUT mühit dəyişənləri oxunur
param([switch]$TestMode)
$ErrorActionPreference = 'Continue'
$Root = if ($TestMode -and $env:PLS_ROOT) { $env:PLS_ROOT } else { Join-Path $env:LOCALAPPDATA 'PLS' }
$OutDir = if ($TestMode -and $env:PLS_TEST_OUT) { $env:PLS_TEST_OUT } else { [Environment]::GetFolderPath('Desktop') }
$HostName = 'az.plsconsulting.updater'

function Hide([string]$s) {
  if (-not $s) { return $s }
  foreach ($p in @($env:USERPROFILE, $env:HOME) | Where-Object { $_ }) { $s = $s.Replace($p, '%USERPROFILE%') }
  if ($env:COMPUTERNAME -and $env:COMPUTERNAME.Length -ge 4) { $s = [regex]::Replace($s, [regex]::Escape($env:COMPUTERNAME), '<kompüter>', 'IgnoreCase') }
  return $s
}
function Sha([string]$f) { try { (Get-FileHash -LiteralPath $f -Algorithm SHA256).Hash.ToLower() } catch { '?' } }

$tmp = Join-Path ([IO.Path]::GetTempPath()) ('pls-diag-' + [guid]::NewGuid().ToString('N'))
New-Item -ItemType Directory -Path $tmp -Force | Out-Null
$lines = New-Object Collections.Generic.List[string]
$add = { param($k, $v) $lines.Add(('{0,-28} {1}' -f $k, (Hide "$v"))) }

& $add 'Tarix' (Get-Date -Format 'yyyy-MM-dd HH:mm:ss zzz')
& $add 'Windows' ([Environment]::OSVersion.VersionString)
& $add 'PowerShell' $PSVersionTable.PSVersion
& $add 'PLS qovluğu' $Root
$mf = Join-Path $Root 'extension\manifest.json'
$ver = try { ([IO.File]::ReadAllText($mf) | ConvertFrom-Json).version } catch { 'quraşdırılmayıb' }
& $add 'Genişlənmənin versiyası' $ver
foreach ($b in @(@{ N = 'Chrome'; K = 'HKCU:\Software\Google\Chrome\BLBeacon' }, @{ N = 'Edge'; K = 'HKCU:\Software\Microsoft\Edge\BLBeacon' })) {
  $v = try { (Get-ItemProperty -Path $b.K -ErrorAction Stop).version } catch { '—' }
  & $add "$($b.N) versiyası" $v
  $h = try { (Get-ItemProperty -Path "HKCU:\Software\$(if ($b.N -eq 'Chrome') { 'Google\Chrome' } else { 'Microsoft\Edge' })\NativeMessagingHosts\$HostName" -ErrorAction Stop).'(default)' } catch { 'qeydiyyatda yoxdur' }
  & $add "$($b.N) körpüsü" $h
}
$st = [Environment]::GetFolderPath('Startup')
& $add 'Startup faylı' $(if ($st) { Test-Path -LiteralPath (Join-Path $st 'PLS Yenileyici.vbs') } else { '—' })
try {
  $t = Get-ScheduledTask -TaskName 'PLS Yenileyici' -ErrorAction Stop
  $ti = $t | Get-ScheduledTaskInfo
  & $add 'Tapşırıq' ("$($t.State), interval $($t.Triggers[0].Repetition.Interval), son: $($ti.LastRunTime), nəticə: $($ti.LastTaskResult), növbəti: $($ti.NextRunTime)")
} catch { & $add 'Tapşırıq' 'yoxdur' }
try {
  $m = [regex]::Match([IO.File]::ReadAllText((Join-Path $Root 'updater\pls-updater.ps1')), '<Modulus>([^<]+)</Modulus>').Groups[1].Value
  $hx = -join ([Security.Cryptography.SHA256]::Create().ComputeHash([Convert]::FromBase64String($m)) | ForEach-Object { $_.ToString('X2') })
  & $add 'Açarın barmaq izi' (($hx.Substring(0, 32) -split '(.{4})' | Where-Object { $_ }) -join '-')
} catch {}
$lines.Add('')
$lines.Add('Fayllar (sha256):')
foreach ($d in 'updater', 'package') {
  Get-ChildItem -LiteralPath (Join-Path $Root $d) -File -ErrorAction SilentlyContinue | ForEach-Object {
    $lines.Add(('  {0,-40} {1,10}  {2}' -f "$d\$($_.Name)", $_.Length, (Sha $_.FullName)))
  }
}
Get-ChildItem -LiteralPath $Root -File -Filter 'PLS-*.cmd' -ErrorAction SilentlyContinue | ForEach-Object { $lines.Add(('  {0,-40} {1,10}  {2}' -f $_.Name, $_.Length, (Sha $_.FullName))) }
[IO.File]::WriteAllLines((Join-Path $tmp 'melumat.txt'), $lines, (New-Object Text.UTF8Encoding $true))

foreach ($lf in (Join-Path $Root 'logs\updater.log'), (Join-Path $Root 'logs\updater.log.1'), (Join-Path $Root 'updater.log')) {
  if (Test-Path -LiteralPath $lf) {
    $txt = Hide ([IO.File]::ReadAllText($lf))
    [IO.File]::WriteAllText((Join-Path $tmp ((Split-Path -Leaf $lf) -replace '^updater', 'yenileyici')), $txt, (New-Object Text.UTF8Encoding $true))
  }
}

$zip = Join-Path $OutDir ('PLS-diaqnostika-' + (Get-Date -Format 'yyyyMMdd-HHmm') + '.zip')
Compress-Archive -Path (Join-Path $tmp '*') -DestinationPath $zip -Force
Remove-Item -LiteralPath $tmp -Recurse -Force -ErrorAction SilentlyContinue
Write-Host ''
Write-Host "  Hazırdır: $zip" -ForegroundColor Green
Write-Host '  Bu faylı PLS dəstəyinə göndərin (+994 10 255 10 55). İçində şifrə və token yoxdur.'
if (-not $TestMode) { try { Start-Process explorer.exe -ArgumentList "/select,`"$zip`"" } catch {} }
