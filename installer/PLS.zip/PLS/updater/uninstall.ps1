﻿# PLS-i kompüterdən silir (Q-51): tapşırıq, Startup, brauzer körpüsü, Başlanğıc menyusu və YALNIZ PLS-in öz faylları.
# Tərtibatçı kompüterindəki "PLS Sinxron" faylları (sync\, github*.cred, sync.json, sync.log, tags-*.txt) toxunulmaz qalır.
# Naməlum fayllar da silinmir — qovluq yalnız boş qalanda silinir.
#   -Ask       əvvəlcə təsdiq soruşur (PLS-Sil.cmd)
#   -TestMode  yalnız testlər: PLS_ROOT mühit dəyişəni oxunur, Windows qeydiyyatına toxunulmur
param([switch]$Ask, [switch]$TestMode)
$ErrorActionPreference = 'SilentlyContinue'
$HostName = 'az.plsconsulting.updater'
$Root = if ($TestMode -and $env:PLS_ROOT) { $env:PLS_ROOT } else { Join-Path $env:LOCALAPPDATA 'PLS' }

if ($Ask) {
  Write-Host ''
  Write-Host '  PLS bu kompüterdən silinəcək (genişlənmənin faylları, yeniləyici, qısayollar).' -ForegroundColor Yellow
  $a = Read-Host '  Davam edilsin? (B = bəli)'
  if ($a -notmatch '^\s*[BbYy]') { Write-Host '  Silinmədi.'; exit 0 }
}

if (-not $TestMode) {
  if (Get-Command Unregister-ScheduledTask -ErrorAction SilentlyContinue) { Unregister-ScheduledTask -TaskName 'PLS Yenileyici' -Confirm:$false -ErrorAction SilentlyContinue }
  Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath('Startup')) 'PLS Yenileyici.vbs') -Force
  Remove-Item -Path "HKCU:\Software\Google\Chrome\NativeMessagingHosts\$HostName" -Recurse -Force
  Remove-Item -Path "HKCU:\Software\Microsoft\Edge\NativeMessagingHosts\$HostName" -Recurse -Force
  Remove-Item -LiteralPath (Join-Path ([Environment]::GetFolderPath('Programs')) 'PLS') -Recurse -Force
}

$own = @('extension', 'updater', 'package', 'logs', 'staging', 'updater.log',
  'PLS-Qurasdir.cmd', 'PLS-Yenile.cmd', 'PLS-Sil.cmd', 'PLS-Diaqnostika.cmd', 'OXU-MENI.txt')
foreach ($p in $own) { Remove-Item -LiteralPath (Join-Path $Root $p) -Recurse -Force }

$dev = @(Get-ChildItem -LiteralPath $Root -Force | Where-Object { $_.Name -match '^(sync|sync\.json|sync\.log|github.*\.cred|tags-.*\.txt)$' } | ForEach-Object { $_.Name })
$left = @(Get-ChildItem -LiteralPath $Root -Force)
if (-not $left.Count) { Remove-Item -LiteralPath $Root -Recurse -Force }

Write-Host ''
Write-Host '  PLS silindi. Chrome-da chrome://extensions səhifəsindən PLS kartını da "Remove" edin.' -ForegroundColor Green
if ($dev.Count) {
  Write-Host "  Tərtibatçı faylları saxlanıldı, 'PLS Sinxron' işləməyə davam edir: $($dev -join ', ')" -ForegroundColor Yellow
} elseif ($left.Count) {
  Write-Host "  Qovluqda başqa fayllar qaldı, silinmədi: $Root" -ForegroundColor Yellow
}
