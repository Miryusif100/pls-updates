﻿# PLS yeniləyici — Windows üçün.
# Son versiyanı GitHub-dakı pls-updates reposundan götürür, paketin PLS açarı ilə imzalandığını
# təsdiqləyir və genişlənmə qovluğunu yeniləyir. İmza düzgün deyilsə heç nə yazmır.
#
# Feed (Q-47): əvvəl github.com/.../pls-updates.git/info/refs-dən main budağının commit SHA-sı alınır
# (keşlənmir), sonra raw.githubusercontent.com/.../<sha>/latest.json və paket eyni <sha>-dan oxunur
# (dəyişməz ünvandır — CDN köhnə nüsxə verə bilməz). Alınmasa, köhnə yol: raw/main/.
# SHA yalnız "harada axtarmaq"dır; "nəyə etibar etmək" həmişə sha256 + RSA imzasıdır.
#
# İstifadə:
#   pls-updater.ps1                 adi yoxlama (tapşırıq hər 15 dəq., Windows açılışı)
#   pls-updater.ps1 -Now            əl ilə "İndi yenilə" (PLS-Yenile.cmd): nəticəni ekranda göstərir;
#                                   internet yoxdursa package\ qovluğundakı imzalı paketdən quraşdırır
#   pls-updater.ps1 -Sha <40 hex>   konkret pls-updates commit-i ilə (genişlənmə və sinxron ötürür)
#   pls-updater.ps1 -Package <zip|json|qovluq>   oflayn paket (imza məcburidir)
#   -Force            eyni versiyanı yenidən yaz (təmir). Köhnə versiyaya qayıtmır.
#   -AllowDowngrade   köhnə versiyanı quraşdırmağa icazə (yalnız dəstək üçün, əl ilə; imza yenə məcburidir)
#   -TestMode         yalnız testlər: PLS_ROOT, PLS_PUBLIC_KEY_XML, PLS_TEST_MACHINE_GUID mühit dəyişənləri oxunur

param(
  [switch]$Force,
  [switch]$Quiet,
  [switch]$Json,
  [string]$Sha = '',
  [switch]$Now,
  [string]$Package = '',
  [switch]$AllowDowngrade,
  [switch]$TestMode
)

$ErrorActionPreference = 'Stop'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

$Script:TestMode = [bool]$TestMode
$Script:QuietLog = [bool]($Quiet -or $Json)
$Script:AllowDowngrade = [bool]$AllowDowngrade
$Script:Owner = 'Miryusif100'
$Script:RepoName = 'pls-updates'
$Script:RefsUrl = "https://github.com/$($Script:Owner)/$($Script:RepoName).git/info/refs?service=git-upload-pack"
$Script:RawBase = "https://raw.githubusercontent.com/$($Script:Owner)/$($Script:RepoName)/"
$Script:TaskName = 'PLS Yenileyici'
$Script:TaskMinutes = 15
$Script:LogMaxBytes = 1MB
$Script:NetFail = $false

$Script:Root = if ($Script:TestMode -and $env:PLS_ROOT) { $env:PLS_ROOT } else { Join-Path $env:LOCALAPPDATA 'PLS' }
$Script:ExtDir = Join-Path $Script:Root 'extension'
$Script:UpdDir = Join-Path $Script:Root 'updater'
$Script:PkgDir = Join-Path $Script:Root 'package'
$Script:LogDir = Join-Path $Script:Root 'logs'
$Script:LogFile = Join-Path $Script:LogDir 'updater.log'
# Paylama dəstinin kökündəki fayllar (C.2). Paketdə pls-updater\ içində gəlir, buradan kökə köçürülür.
$Script:KitFiles = @('PLS-Qurasdir.cmd', 'PLS-Yenile.cmd', 'PLS-Sil.cmd', 'PLS-Diaqnostika.cmd', 'OXU-MENI.txt')

# PLS buraxılış açarının AÇIQ hissəsi (gizli hissə yalnız GitHub Secrets-də və sahibin acarlar\ qovluğundadır).
$Script:PublicKeyXml = '<RSAKeyValue><Modulus>2qPQNnIy15Pj4ziFkXnD3qEaomX6mIuTAxzw4ktKHS0ykZvyWmUb2DT78QdD9IKhZC4p+pjYc8e1ADAkbQQlBdtIr/0DEwSYRttHiWHdZBq0aaV0Ub5xWProBJ+qu9jQCcg1dd+8JbCK0RjgSRdCXewZtqaMxINzCQ9H4LJTrCi70OjU4P+YhO/UKAtDVEiBW92oboQ3jy+KRcXUvB1qhBszqqPAVxtGybkVSrC4JJcRI5kz5iu0GLM+VQWjxULejwqDXEMHquVhMDvDpBKOyrq+8ajS8LC2NiPj1mXb0ph/S7EawT8umOhNClZ5LvrZNhbPdBhhoEUkv5CGSEWPGmFa+vSrSgCUdmbYzPXGqwk7cB8m5E2704FRfrRWBR4NaVVOTi4551ipuNpfXHU52qlXJMN5dPU/IunA02mZ4270LnBIlat/eihlkyRjaFKxKhqjVlRyz3JLPvOcZwdmFNfmSgoFiQEBsXYMDJYrgdesK2S1f63foqjkkn5mUBg1</Modulus><Exponent>AQAB</Exponent></RSAKeyValue>'
if ($Script:TestMode -and $env:PLS_PUBLIC_KEY_XML) { $Script:PublicKeyXml = $env:PLS_PUBLIC_KEY_XML }

# Köhnə "PLS Sinxron" skripti yeniləyicini PLS_FEED_BASE=raw/<sha>/ ilə çağırır. Yalnız bu dəqiq formada qəbul olunur:
# o, yalnız commit-i seçir, imza yoxlaması dəyişmir (T-11).
if (-not $Sha -and $env:PLS_FEED_BASE) {
  $fm = [regex]::Match($env:PLS_FEED_BASE, '^https://raw\.githubusercontent\.com/Miryusif100/pls-updates/([0-9a-f]{40})/$')
  if ($fm.Success) { $Sha = $fm.Groups[1].Value }
}

function Write-PlsLog([string]$Message) {
  try {
    if (-not (Test-Path -LiteralPath $Script:LogDir)) { New-Item -ItemType Directory -Path $Script:LogDir -Force | Out-Null }
    $old = Join-Path $Script:Root 'updater.log'   # 0.7.0-a qədər jurnal kökdə idi
    if ((Test-Path -LiteralPath $old) -and -not (Test-Path -LiteralPath $Script:LogFile)) { Move-Item -LiteralPath $old -Destination $Script:LogFile -Force }
    if ((Test-Path -LiteralPath $Script:LogFile) -and (Get-Item -LiteralPath $Script:LogFile).Length -gt $Script:LogMaxBytes) {
      Move-Item -LiteralPath $Script:LogFile -Destination ($Script:LogFile + '.1') -Force
    }
    $line = '[{0}] {1}' -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss'), $Message
    Add-Content -LiteralPath $Script:LogFile -Value $line -Encoding UTF8
  } catch {}
  if (-not $Script:QuietLog) { Write-Host ('  ' + $Message) }
}

function Get-PlsLocalVersion {
  $mf = Join-Path $Script:ExtDir 'manifest.json'
  if (-not (Test-Path -LiteralPath $mf)) { return '0.0.0' }
  try { return ([IO.File]::ReadAllText($mf) | ConvertFrom-Json).version } catch { return '0.0.0' }
}

# Kompüterin sabit ID-si: Windows-un MachineGuid dəyərinin hash-i (dəyərin özü heç yerə göndərilmir).
function Get-PlsDevice {
  $guid = if ($Script:TestMode) { $env:PLS_TEST_MACHINE_GUID } else { $null }
  if (-not $guid) {
    $base = [Microsoft.Win32.RegistryKey]::OpenBaseKey([Microsoft.Win32.RegistryHive]::LocalMachine, [Microsoft.Win32.RegistryView]::Registry64)
    $guid = $base.OpenSubKey('SOFTWARE\Microsoft\Cryptography').GetValue('MachineGuid')
  }
  if (-not $guid) { throw 'Kompüterin ID-si oxunmadı' }
  $sha = [Security.Cryptography.SHA256]::Create()
  $id = -join ($sha.ComputeHash([Text.Encoding]::UTF8.GetBytes('pls-device-v1:' + $guid)) | ForEach-Object { $_.ToString('x2') })
  $name = if ($env:COMPUTERNAME) { $env:COMPUTERNAME } else { [Environment]::MachineName }
  return [pscustomobject]@{ success = $true; device_id = $id; device_name = $name }
}

function ConvertTo-PlsVersion([string]$v) {
  $p = @(("$v" -split '\.') | ForEach-Object { [int]$_ })
  while ($p.Count -lt 3) { $p += 0 }
  return New-Object Version($p[0], $p[1], $p[2])
}
function Test-PlsNewer([string]$a, [string]$b) { return (ConvertTo-PlsVersion $a) -gt (ConvertTo-PlsVersion $b) }

function Get-PlsSha256([byte[]]$Data) {
  $h = [Security.Cryptography.SHA256]::Create()
  return -join ($h.ComputeHash($Data) | ForEach-Object { $_.ToString('x2') })
}

function Test-PlsSignature([byte[]]$Data, [string]$SignatureB64) {
  $rsa = [Security.Cryptography.RSA]::Create()
  $rsa.FromXmlString($Script:PublicKeyXml)
  try { $sig = [Convert]::FromBase64String($SignatureB64) } catch { return $false }
  return $rsa.VerifyData($Data, $sig, [Security.Cryptography.HashAlgorithmName]::SHA256, [Security.Cryptography.RSASignaturePadding]::Pkcs1)
}

# Açıq açarın barmaq izi (modulun SHA-256-sı) — quraşdırıcı ekranda göstərir, ayrı kanalla müqayisə üçün (T-08).
function Get-PlsKeyFingerprint {
  $m = [regex]::Match($Script:PublicKeyXml, '<Modulus>([^<]+)</Modulus>').Groups[1].Value
  $hex = (Get-PlsSha256 ([Convert]::FromBase64String($m))).ToUpper().Substring(0, 32)
  return (($hex -split '(.{4})' | Where-Object { $_ }) -join '-')
}

function Get-PlsBytes([string]$Url) {
  $wc = New-Object Net.WebClient
  $wc.Headers.Add('Cache-Control', 'no-cache')
  $wc.Headers.Add('User-Agent', 'PLS-updater')
  try { return $wc.DownloadData($Url) } finally { $wc.Dispose() }
}

# info/refs cavabından (git "smart HTTP" reklamı) main budağının SHA-sı.
function Read-PlsMainSha([string]$RefsText) {
  $m = [regex]::Match($RefsText, '([0-9a-f]{40}) refs/heads/main(?=[\x00\r\n]|$)')
  if ($m.Success) { return $m.Groups[1].Value }
  return $null
}

function Get-PlsMainSha {
  $txt = [Text.Encoding]::ASCII.GetString((Get-PlsBytes $Script:RefsUrl))
  $s = Read-PlsMainSha $txt
  if (-not $s) { throw 'info/refs cavabında main budağı tapılmadı' }
  return $s
}

function Test-PlsFeed($Feed) {
  if (-not $Feed.version -or -not $Feed.file -or -not $Feed.sha256 -or -not $Feed.signature) { throw 'latest.json formatı səhvdir' }
  if ("$($Feed.version)" -notmatch '^\d+\.\d+\.\d+$') { throw "latest.json-da versiya səhvdir: $($Feed.version)" }
  if ("$($Feed.file)" -notmatch '^releases/pls-\d+\.\d+\.\d+\.zip$') { throw "latest.json-da fayl adı səhvdir: $($Feed.file)" }
}

# Feed-i tapır: -Sha → həmin commit; yoxdursa info/refs → SHA; alınmasa raw/main (CDN, 5 dəq.-yə qədər köhnə ola bilər).
function Resolve-PlsFeed([string]$Sha) {
  $Script:NetFail = $false
  if ($Sha) {
    if ($Sha -cnotmatch '^[0-9a-f]{40}$') { throw "Yanlış commit SHA: $Sha" }
  } else {
    try { $Sha = Get-PlsMainSha } catch { Write-PlsLog "info/refs alınmadı ($($_.Exception.Message)) — raw/main istifadə olunur."; $Sha = '' }
  }
  if ($Sha) {
    $base = $Script:RawBase + $Sha + '/'
    try {
      $text = [Text.Encoding]::UTF8.GetString((Get-PlsBytes ($base + 'latest.json')))
      return [pscustomobject]@{ Feed = ($text | ConvertFrom-Json); Base = $base; Sha = $Sha; Query = '' }
    } catch { Write-PlsLog "raw/$Sha/latest.json alınmadı ($($_.Exception.Message)) — raw/main istifadə olunur." }
  }
  $base = $Script:RawBase + 'main/'
  $q = '?t=' + [DateTimeOffset]::UtcNow.ToUnixTimeSeconds()
  try { $text = [Text.Encoding]::UTF8.GetString((Get-PlsBytes ($base + 'latest.json' + $q))) }
  catch { $Script:NetFail = $true; throw "Yeniləmə serveri ilə əlaqə alınmadı: $($_.Exception.Message)" }
  return [pscustomobject]@{ Feed = ($text | ConvertFrom-Json); Base = $base; Sha = ''; Query = $q }
}

function New-PlsResult([bool]$Ok, [bool]$Updated, [string]$Version, [string]$Latest, [string]$Message, [string]$Source = '', [string]$Sha = '') {
  return [pscustomobject]@{ success = $Ok; updated = $Updated; version = $Version; latest = $Latest; message = $Message; source = $Source; sha = $Sha }
}

# Versiyanı yazmaq lazımdırmı? $null — lazımdır; əks halda "yazılmır" nəticəsi.
function Test-PlsSkip($Feed, [string]$Local, [bool]$ForceUpdate, [string]$Source, [string]$Sha) {
  $v = "$($Feed.version)"
  if (Test-PlsNewer $Local $v) {
    if ($Script:AllowDowngrade) { Write-PlsLog "DİQQƏT: köhnə versiya quraşdırılır ($Local -> $v), -AllowDowngrade ilə."; return $null }
    Write-PlsLog "Köhnə versiya quraşdırılmır: quraşdırılıb $Local, təklif olunan $v."
    return (New-PlsResult $true $false $Local $v "Quraşdırılmış versiya ($Local) təklif olunandan ($v) yenidir — köhnə versiya quraşdırılmır" $Source $Sha)
  }
  if (-not $ForceUpdate -and -not (Test-PlsNewer $v $Local)) {
    Write-PlsLog "Yeni versiya yoxdur. Quraşdırılıb: $Local, son: $v"
    return (New-PlsResult $true $false $Local $v 'Son versiya quraşdırılıb' $Source $Sha)
  }
  return $null
}

function Test-PlsEntryName([string]$Name) {
  if (-not $Name -or $Name.Contains('\') -or $Name.Contains(':') -or $Name.StartsWith('/')) { return $false }
  foreach ($seg in $Name.Split('/')) { if ($seg -eq '..') { return $false } }
  return $true
}

function Write-PlsEntry($Entry, [string]$Dest) {
  $dir = Split-Path -Parent $Dest
  if (-not (Test-Path -LiteralPath $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
  $in = $Entry.Open()
  try {
    $out = [IO.File]::Create($Dest)
    try { $in.CopyTo($out) } finally { $out.Dispose() }
  } finally { $in.Dispose() }
}

# Yoxlanmış baytları quraşdırır. Arxiv diskə yazılmır — birbaşa yaddaşdakı, imzası yoxlanmış baytlardan açılır (T-12).
function Install-PlsBytes([byte[]]$Bytes, $Feed, [string]$Source, [string]$Sha) {
  $local = Get-PlsLocalVersion
  $hash = Get-PlsSha256 $Bytes
  if ($hash -ne "$($Feed.sha256)".ToLower()) { throw "Faylın hash-i uyğun gəlmir ($hash)" }
  if (-not (Test-PlsSignature $Bytes $Feed.signature)) { throw 'İMZA DÜZGÜN DEYİL — fayl PLS tərəfindən imzalanmayıb, quraşdırılmadı' }
  Write-PlsLog 'İmza təsdiqləndi.'

  Add-Type -AssemblyName System.IO.Compression
  $ms = New-Object IO.MemoryStream(, $Bytes)
  $zip = New-Object IO.Compression.ZipArchive($ms, [IO.Compression.ZipArchiveMode]::Read)
  try {
    $files = @($zip.Entries | Where-Object { -not $_.FullName.EndsWith('/') })
    foreach ($e in $files) { if (-not (Test-PlsEntryName $e.FullName)) { throw "Paketdə icazəsiz fayl yolu: $($e.FullName)" } }
    $mfEntry = $files | Where-Object { $_.FullName -eq 'manifest.json' } | Select-Object -First 1
    if (-not $mfEntry) { throw 'Paketdə manifest.json yoxdur' }
    $sr = New-Object IO.StreamReader($mfEntry.Open(), [Text.Encoding]::UTF8)
    try { $newVer = ($sr.ReadToEnd() | ConvertFrom-Json).version } finally { $sr.Dispose() }
    if ($newVer -ne "$($Feed.version)") { throw "Paketin versiyası ($newVer) elanla ($($Feed.version)) uyğun deyil" }

    # 1) Yeniləyicinin öz faylları (pls-updater/, yalnız birinci səviyyə) → updater\
    $updFiles = @($files | Where-Object { $_.FullName -match '^pls-updater/[^/]+$' })
    if ($updFiles.Count) {
      if (-not (Test-Path -LiteralPath $Script:UpdDir)) { New-Item -ItemType Directory -Path $Script:UpdDir -Force | Out-Null }
      foreach ($e in $updFiles) {
        try { Write-PlsEntry $e (Join-Path $Script:UpdDir $e.Name) } catch { Write-PlsLog "Yeniləyici faylı yenilənmədi: $($e.Name)" }
      }
      Write-PlsLog 'Yeniləyicinin özü də yeniləndi.'
    }

    # 2) Genişlənmə: əvvəl manifest-dən başqa hər şey, manifest ən sonda (Chrome yarımçıq versiyanı götürməsin)
    $extFiles = @($files | Where-Object { -not $_.FullName.StartsWith('pls-updater/') })
    if (-not (Test-Path -LiteralPath $Script:ExtDir)) { New-Item -ItemType Directory -Path $Script:ExtDir -Force | Out-Null }
    foreach ($e in $extFiles) { if ($e.FullName -ne 'manifest.json') { Write-PlsEntry $e (Join-Path $Script:ExtDir $e.FullName) } }
    Write-PlsEntry $mfEntry (Join-Path $Script:ExtDir 'manifest.json')

    # 3) Köhnə versiyadan qalan artıq fayllar
    $keep = @{}; foreach ($e in $extFiles) { $keep[$e.FullName.ToLower()] = $true }
    Get-ChildItem -LiteralPath $Script:ExtDir -Recurse -File | ForEach-Object {
      $rel = $_.FullName.Substring($Script:ExtDir.Length).TrimStart('\', '/').Replace('\', '/')
      if (-not $keep.ContainsKey($rel.ToLower())) { Remove-Item -LiteralPath $_.FullName -Force -ErrorAction SilentlyContinue }
    }
  } finally { $zip.Dispose(); $ms.Dispose() }

  # 4) Oflayn quraşdırma/təmir üçün son imzalı paket package\-də saxlanılır
  if ($Source -ne 'package') { Save-PlsPackage $Bytes $Feed }
  Sync-PlsKit
  Write-PlsLog "Yeniləndi: $local -> $($Feed.version). Chrome genişlənməni 30 saniyə ərzində özü yenidən yükləyəcək."
  return (New-PlsResult $true $true "$($Feed.version)" "$($Feed.version)" "Yeniləndi: $($Feed.version)" $Source $Sha)
}

function Save-PlsPackage([byte[]]$Bytes, $Feed) {
  try {
    if (-not (Test-Path -LiteralPath $Script:PkgDir)) { New-Item -ItemType Directory -Path $Script:PkgDir -Force | Out-Null }
    $name = "pls-$($Feed.version)"
    Get-ChildItem -LiteralPath $Script:PkgDir -File -Filter 'pls-*' | Where-Object { $_.BaseName -ne $name } | Remove-Item -Force -ErrorAction SilentlyContinue
    [IO.File]::WriteAllBytes((Join-Path $Script:PkgDir "$name.zip"), $Bytes)
    $meta = [ordered]@{ version = "$($Feed.version)"; file = "$($Feed.file)"; sha256 = "$($Feed.sha256)"; signature = "$($Feed.signature)"; size = $Bytes.Length; released = "$($Feed.released)"; notes = @($Feed.notes) }
    [IO.File]::WriteAllText((Join-Path $Script:PkgDir "$name.json"), ($meta | ConvertTo-Json -Depth 4), (New-Object Text.UTF8Encoding $false))
  } catch { Write-PlsLog "package\ yenilənmədi: $($_.Exception.Message)" }
}

# Kökdəki istifadəçi faylları (PLS-Yenile.cmd və s.) paketlə updater\-ə gəlir; burada kökə köçürülür.
function Sync-PlsKit {
  if (-not (Test-Path -LiteralPath $Script:UpdDir)) { return }
  foreach ($f in $Script:KitFiles) {
    $src = Join-Path $Script:UpdDir $f
    $dst = Join-Path $Script:Root $f
    if (-not (Test-Path -LiteralPath $src)) { continue }
    try {
      if ((Test-Path -LiteralPath $dst) -and ((Get-PlsSha256 ([IO.File]::ReadAllBytes($src))) -eq (Get-PlsSha256 ([IO.File]::ReadAllBytes($dst))))) { continue }
      Copy-Item -LiteralPath $src -Destination $dst -Force
    } catch { Write-PlsLog "$f yenilənmədi: $($_.Exception.Message)" }
  }
}

function Invoke-PlsUpdate([switch]$ForceUpdate, [string]$Sha = '') {
  $local = Get-PlsLocalVersion
  $r = Resolve-PlsFeed $Sha
  $feed = $r.Feed
  Test-PlsFeed $feed
  $src = if ($r.Sha) { 'sha' } else { 'main' }
  $skip = Test-PlsSkip $feed $local ([bool]$ForceUpdate) $src $r.Sha
  if ($skip) { return $skip }
  $where = if ($r.Sha) { "commit $($r.Sha.Substring(0, 7))" } else { 'raw/main' }
  Write-PlsLog "Yeni versiya: $($feed.version) (quraşdırılıb: $local, $where). Yüklənir..."
  try { $bytes = Get-PlsBytes ($r.Base + $feed.file + $r.Query) }
  catch { $Script:NetFail = $true; throw "Paket endirilmədi: $($_.Exception.Message)" }
  return (Install-PlsBytes $bytes $feed $src $r.Sha)
}

# Oflayn paket: qovluq (package\), pls-X.Y.Z.zip (yanında eyni adlı .json) və ya pls-X.Y.Z.json.
function Resolve-PlsPackage([string]$Path) {
  if (-not (Test-Path -LiteralPath $Path)) { throw "Paket tapılmadı: $Path" }
  $item = Get-Item -LiteralPath $Path
  if ($item.PSIsContainer) {
    $cands = @(Get-ChildItem -LiteralPath $item.FullName -File -Filter 'pls-*.json' | ForEach-Object {
        try { $j = [IO.File]::ReadAllText($_.FullName) | ConvertFrom-Json; [pscustomobject]@{ Json = $_.FullName; Feed = $j } } catch {}
      } | Where-Object { $_ -and "$($_.Feed.version)" -match '^\d+\.\d+\.\d+$' })
    if (-not $cands.Count) { throw "Qovluqda imzalı paket yoxdur (pls-X.Y.Z.zip + pls-X.Y.Z.json): $($item.FullName)" }
    $jsonPath = ($cands | Sort-Object { ConvertTo-PlsVersion "$($_.Feed.version)" } -Descending | Select-Object -First 1).Json
  } elseif ($item.Extension -eq '.json') { $jsonPath = $item.FullName }
  else {
    $jsonPath = [IO.Path]::ChangeExtension($item.FullName, '.json')
    if (-not (Test-Path -LiteralPath $jsonPath)) { throw "İmza faylı tapılmadı: $jsonPath (paketin yanında eyni adlı .json olmalıdır)" }
  }
  $feed = [IO.File]::ReadAllText($jsonPath) | ConvertFrom-Json
  Test-PlsFeed $feed
  $zipPath = if (-not $item.PSIsContainer -and $item.Extension -eq '.zip') { $item.FullName } else { Join-Path (Split-Path -Parent $jsonPath) (Split-Path -Leaf "$($feed.file)") }
  if (-not (Test-Path -LiteralPath $zipPath)) { throw "Paket faylı tapılmadı: $zipPath" }
  return [pscustomobject]@{ Feed = $feed; Zip = $zipPath }
}

function Invoke-PlsPackageInstall([string]$Path, [switch]$ForceUpdate) {
  $local = Get-PlsLocalVersion
  $p = Resolve-PlsPackage $Path
  Write-PlsLog "Oflayn paket: $($p.Zip) (versiya $($p.Feed.version))."
  $skip = Test-PlsSkip $p.Feed $local ([bool]$ForceUpdate) 'package' ''
  if ($skip) { return $skip }
  $bytes = [IO.File]::ReadAllBytes($p.Zip)
  $here = [IO.Path]::GetFullPath((Split-Path -Parent $p.Zip)).TrimEnd('\', '/')
  $src = if ($here -eq [IO.Path]::GetFullPath($Script:PkgDir).TrimEnd('\', '/')) { 'package' } else { 'file' }
  return (Install-PlsBytes $bytes $p.Feed $src '')
}

# "PLS Yenileyici" tapşırığı saatlıq qalıbsa, 15 dəqiqəyə keçirilir (Q-48; administrator lazım deyil).
function Update-PlsTask {
  if ($Script:TestMode -or -not (Get-Command Get-ScheduledTask -ErrorAction SilentlyContinue)) { return }
  try {
    $t = Get-ScheduledTask -TaskName $Script:TaskName -ErrorAction SilentlyContinue
    if (-not $t) { return }   # tapşırığı yalnız quraşdırıcı yaradır
    if ($t.Triggers.Count -and "$($t.Triggers[0].Repetition.Interval)" -eq "PT$($Script:TaskMinutes)M") { return }
    Register-PlsTask
    Write-PlsLog "Tapşırıq yeniləndi: hər $($Script:TaskMinutes) dəqiqə."
  } catch { Write-PlsLog "Tapşırıq yenilənmədi: $($_.Exception.Message)" }
}

function Register-PlsTask {
  $vbsPath = Join-Path $Script:UpdDir 'run-updater.vbs'
  $action = New-ScheduledTaskAction -Execute 'wscript.exe' -Argument "`"$vbsPath`""
  $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(2) -RepetitionInterval (New-TimeSpan -Minutes $Script:TaskMinutes) -RepetitionDuration (New-TimeSpan -Days 3650)
  $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -ExecutionTimeLimit (New-TimeSpan -Minutes 10)
  Register-ScheduledTask -TaskName $Script:TaskName -Action $action -Trigger $trigger -Settings $settings -Force | Out-Null
}

# Birbaşa işə salınıbsa (native host və ya test tərəfindən "dot-source" edilməyibsə) yeniləməni icra et.
if ($MyInvocation.InvocationName -ne '.') {
  if ($Now -and -not $Json) {
    Write-Host ''
    Write-Host '  PLS — yeniləmə' -ForegroundColor Green
    Write-Host '  --------------'
  }
  try {
    if ($Package) {
      $r = Invoke-PlsPackageInstall $Package -ForceUpdate:$Force
    } else {
      try { $r = Invoke-PlsUpdate -ForceUpdate:$Force -Sha $Sha }
      catch {
        $hasPkg = (Test-Path -LiteralPath $Script:PkgDir) -and @(Get-ChildItem -LiteralPath $Script:PkgDir -File -Filter 'pls-*.json' -ErrorAction SilentlyContinue).Count
        if ($Script:NetFail -and $Now -and $hasPkg) {
          Write-PlsLog "İnternet yoxdur ($($_.Exception.Message)) — package\ qovluğundakı imzalı paket yoxlanılır."
          $r = Invoke-PlsPackageInstall $Script:PkgDir -ForceUpdate:$Force
        } else { throw }
      }
    }
  } catch {
    Write-PlsLog ('XƏTA: ' + $_.Exception.Message)
    $r = New-PlsResult $false $false (Get-PlsLocalVersion) '' $_.Exception.Message
  }
  Update-PlsTask
  try { Sync-PlsKit } catch {}
  if ($Json) { $r | ConvertTo-Json -Compress }
  elseif ($Now) {
    Write-Host ''
    if (-not $r.success) { Write-Host "  X Yeniləmə alınmadı: $($r.message)" -ForegroundColor Red }
    elseif ($r.updated) { Write-Host "  OK PLS $($r.version) quraşdırıldı. Chrome genişlənməni 30 saniyə ərzində özü yeniləyəcək (açıq İdarə paneli yenidən açılır)." -ForegroundColor Green }
    else { Write-Host "  OK $($r.message). Quraşdırılmış versiya: $($r.version)" -ForegroundColor Green }
  }
  if (-not $r.success) { exit 1 }
}
