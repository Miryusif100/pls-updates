﻿# PLS quraşdırıcısı. Administrator icazəsi tələb etmir; hər şey istifadəçinin öz qovluğuna yazılır.
$ErrorActionPreference = 'Stop'
$ExtensionId = 'mgfgihjfnhhmbljfcpknoomaljpgfalf'
$HostName = 'az.plsconsulting.updater'

$Root = Join-Path $env:LOCALAPPDATA 'PLS'
$UpdDir = Join-Path $Root 'updater'
$ExtDir = Join-Path $Root 'extension'

Write-Host ''
Write-Host '  PLS Consulting — PLS genişlənməsinin quraşdırılması' -ForegroundColor Green
Write-Host '  ---------------------------------------------------'
Write-Host ''

# 1) Faylları köçür
New-Item -ItemType Directory -Path $UpdDir -Force | Out-Null
foreach ($f in 'pls-updater.ps1', 'native-host.ps1', 'native-host.cmd', 'run-updater.vbs', 'uninstall.ps1') {
  Copy-Item -LiteralPath (Join-Path $PSScriptRoot $f) -Destination (Join-Path $UpdDir $f) -Force
}
Get-ChildItem $UpdDir | Unblock-File -ErrorAction SilentlyContinue
Write-Host "  [1/5] Yeniləyici quraşdırıldı: $UpdDir"

# 2) Chrome və Edge üçün "İndi yenilə" körpüsü (native messaging)
$hostManifest = [ordered]@{
  name = $HostName
  description = 'PLS yeniləyici'
  path = (Join-Path $UpdDir 'native-host.cmd')
  type = 'stdio'
  allowed_origins = @("chrome-extension://$ExtensionId/")
}
$hostJson = Join-Path $UpdDir "$HostName.json"
[IO.File]::WriteAllText($hostJson, ($hostManifest | ConvertTo-Json), (New-Object Text.UTF8Encoding $false))
foreach ($browserKey in 'HKCU:\Software\Google\Chrome\NativeMessagingHosts', 'HKCU:\Software\Microsoft\Edge\NativeMessagingHosts') {
  $k = Join-Path $browserKey $HostName
  New-Item -Path $k -Force | Out-Null
  Set-ItemProperty -Path $k -Name '(default)' -Value $hostJson
}
Write-Host '  [2/5] Brauzer körpüsü qeydiyyatdan keçdi'

# 3) Windows açılanda avtomatik yoxlama (Startup qovluğu)
$startup = [Environment]::GetFolderPath('Startup')
Copy-Item -LiteralPath (Join-Path $UpdDir 'run-updater.vbs') -Destination (Join-Path $startup 'PLS Yenileyici.vbs') -Force
# Startup-dakı nüsxə yeniləyicini öz qovluğunda axtarır — yolu sabitləyirik
$vbs = Join-Path $startup 'PLS Yenileyici.vbs'
$content = [IO.File]::ReadAllText($vbs).Replace('dir = CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)', "dir = `"$UpdDir`"")
[IO.File]::WriteAllText($vbs, $content, [Text.Encoding]::Default)
Write-Host '  [3/5] Windows açılanda avtomatik yoxlama aktivdir'

# 4) Hər saat yoxlama (Tapşırıq planlayıcısı, administrator tələb etmir)
$vbsPath = Join-Path $UpdDir 'run-updater.vbs'
try {
  $action = New-ScheduledTaskAction -Execute 'wscript.exe' -Argument "`"$vbsPath`""
  $trigger = New-ScheduledTaskTrigger -Once -At (Get-Date).AddMinutes(5) -RepetitionInterval (New-TimeSpan -Hours 1) -RepetitionDuration (New-TimeSpan -Days 3650)
  $settings = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable
  Register-ScheduledTask -TaskName 'PLS Yenileyici' -Action $action -Trigger $trigger -Settings $settings -Force | Out-Null
} catch {
  Write-Host "  (Saatlıq tapşırıq yaradılmadı: $($_.Exception.Message). Windows açılanda yoxlama işləyəcək.)" -ForegroundColor Yellow
}
Write-Host '  [4/5] Saatlıq yoxlama planlaşdırıldı'

# 5) Son versiyanı yüklə
Write-Host '  [5/5] Son versiya yüklənir...'
& powershell.exe -NoProfile -ExecutionPolicy Bypass -File (Join-Path $UpdDir 'pls-updater.ps1') -Force
if ($LASTEXITCODE -ne 0) { throw 'Son versiyanı yükləmək alınmadı. İnternet bağlantısını yoxlayın və yenidən cəhd edin.' }

Set-Clipboard -Value $ExtDir -ErrorAction SilentlyContinue
Write-Host ''
Write-Host '  Hazırdır! Son addım — Chrome-da bir dəfə:' -ForegroundColor Green
Write-Host '    1. Ünvan sətrinə yazın: chrome://extensions'
Write-Host '    2. Sağ yuxarıda "Developer mode" açın'
Write-Host '    3. "Load unpacked" basın və bu qovluğu seçin (yolu artıq kopyaladım, Ctrl+V edin):'
Write-Host "       $ExtDir" -ForegroundColor Yellow
Write-Host ''
Write-Host '  Bundan sonra yeniləmələr avtomatikdir.'
Write-Host ''
